import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from contextlib import nullcontext
from tempfile import TemporaryDirectory
from threading import Event, Thread
from types import SimpleNamespace


workspace = Path(__file__).resolve().parent.parent
source = workspace / "plugins/stalker2-modding/skills/stalker2-modding/scripts/zonekit-bridge"
temporary = TemporaryDirectory(prefix=".test-", dir=workspace)
test_dir = Path(temporary.name)
os.environ["ZONEKIT_MCP_HOME"] = str(test_dir)
for name in ("zonekit_bridge.py", "zonekit_mcp.py", "zonekit_tools.py"):
    shutil.copyfile(source / name, test_dir / name)
sys.path.insert(0, str(test_dir))

from zonekit_bridge import BridgeError, DEFAULT_PATH, EditorWorker, ROOT, call
from zonekit_tools import TOOLS, validate


blueprint_path = f"{DEFAULT_PATH}/BP_ChemLightProp"
stock_path = "/Game/Props/BP_Stock"
new_blueprint_path = "/AnotherMod/Fixtures/BP_New"


class Blueprint:
    def __init__(self, path=blueprint_path):
        self.path = path
        self.fields = {"initial_life_span": 0.0}
        self.graphs = {}
        self.variables = {}

    def get_path_name(self):
        return self.path + "." + self.path.rsplit("/", 1)[-1]

    def get_class(self):
        return SimpleNamespace(get_path_name=lambda: "/Script/Engine.Blueprint")

    def generated_class(self):
        return SimpleNamespace(get_path_name=lambda: self.get_path_name() + "_C", defaults=self)

    def get_editor_property(self, name):
        return self.fields[name]

    def set_editor_property(self, name, value):
        self.fields[name] = value

    def modify(self):
        pass


class PointLight:
    def __init__(self):
        self.fields = {
            "intensity": 250.0, "attenuation_radius": 500.0, "intensity_units": "CANDELAS",
            "source_radius": 0.0, "soft_source_radius": 0.0, "source_length": 0.0,
            "cast_shadows": True, "specular_scale": 1.0, "use_inverse_squared_falloff": True, "absolute_location": False,
        }
        self.edits = []

    def get_class(self):
        return SimpleNamespace(get_name=lambda: "PointLightComponent")

    def get_path_name(self):
        return blueprint_path + ".BP_ChemLightProp_C:BluePointLight"

    def get_editor_property(self, name):
        return self.fields[name]

    def set_editor_property(self, name, value):
        self.fields[name] = value
        self.edits.append((name, value))

    def modify(self):
        pass


blueprint = Blueprint()
assets = {blueprint_path: blueprint, stock_path: Blueprint(stock_path)}
light = PointLight()
save_calls = []
compile_calls = []
state = SimpleNamespace(pie=False)


def create_blueprint(path, _parent):
    assets[path] = Blueprint(path)
    return assets[path]


def add_function(bp, name):
    graph = SimpleNamespace(get_name=lambda: name)
    bp.graphs[name] = graph
    return graph


def add_variable(bp, name, variable_type):
    if name in bp.variables:
        return False
    bp.variables[name] = variable_type
    return True


def get_assets(path, *, recursive, include_folder):
    assert (path, recursive, include_folder) == (DEFAULT_PATH, False, False)
    return [f"{path}/SM_ChemLight.SM_ChemLight"]


with_fake_editor = SimpleNamespace(
    SystemLibrary=SimpleNamespace(get_engine_version=lambda: "5.5.4", get_game_name=lambda: "Stalker2"),
    EditorAssetLibrary=SimpleNamespace(
        does_asset_exist=lambda path: path == "/Flares/Flares" or path in assets,
        does_directory_exist=lambda path: path == DEFAULT_PATH,
        list_assets=get_assets,
        load_asset=assets.get,
        save_loaded_asset=lambda item, **_: save_calls.append(item) is None,
    ),
    AssetRegistryHelpers=SimpleNamespace(get_asset_registry=lambda: SimpleNamespace(
        is_loading_assets=lambda: False, get_sub_paths=lambda *_: ["/Game", "/Flares", "/AnotherMod"],
    )),
    ActorComponent=PointLight,
    PointLightComponent=PointLight,
    Blueprint=Blueprint,
    SubobjectDataSubsystem=object,
    get_engine_subsystem=lambda _: SimpleNamespace(
        k2_gather_subobject_data_for_blueprint=lambda _: [light],
        k2_find_subobject_data_from_handle=lambda handle: handle,
    ),
    SubobjectDataBlueprintFunctionLibrary=SimpleNamespace(
        get_variable_name=lambda _: "BluePointLight",
        get_object_for_blueprint=lambda component, _: component,
    ),
    BlueprintEditorLibrary=SimpleNamespace(
        find_event_graph=lambda _: SimpleNamespace(get_name=lambda: "EventGraph"),
        find_graph=lambda bp, name: bp.graphs.get(name),
        add_function_graph=add_function,
        add_member_variable=add_variable,
        get_basic_type_by_name=lambda name: name,
        create_blueprint_asset_with_parent=create_blueprint,
        compile_blueprint=compile_calls.append,
    ),
    load_class=lambda _, name: name if name == "/Script/Engine.Actor" else None,
    get_default_object=lambda generated: generated.defaults,
    EditorLevelLibrary=SimpleNamespace(get_pie_worlds=lambda _: [object()] if state.pie else []),
    ScopedEditorTransaction=lambda _: nullcontext(),
    log_warning=lambda _: None,
)
worker = EditorWorker(with_fake_editor, ROOT)
done = Event()


def poll():
    while not done.wait(0.02):
        worker.tick(0)


worker.heartbeat()
thread = Thread(target=poll, daemon=True)
thread.start()
try:
    result = call("status", {})
    assert result["flares_registered"] and result["engine_version"] == "5.5.4"
    assert result["writes_enabled"] is False
    result = call("list_assets", {})
    assert result["exists"] and result["count"] == 1
    try:
        call("list_assets", {"path": "/Game/../Outside"})
    except BridgeError:
        pass
    else:
        raise AssertionError("Malformed path accepted")
    assert call("list_mounts", {})["mounts"] == ["/AnotherMod", "/Flares", "/Game"]
    assert call("get_asset", {"asset": stock_path})["class"] == "/Script/Engine.Blueprint"
    capabilities = call("graph_capabilities", {})
    assert capabilities["create_blueprint"] and not capabilities["import_nodes"]
    inspection = call("inspect_blueprint", {"asset": blueprint_path})
    assert inspection["event_graph"] == "EventGraph"
    assert inspection["components"][0]["radius_cm"] == 500
    edit = {"asset": blueprint_path, "component": "BluePointLight", "radius_cm": 600}
    try:
        call("set_point_light", edit)
    except BridgeError as error:
        assert "read-only" in str(error)
    else:
        raise AssertionError("Read-only session accepted a write")
    assert not light.edits

    requests = [
        {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "smoke", "version": "1"}}},
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "zonekit_list_assets", "arguments": {"path": DEFAULT_PATH}}},
        {"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "zonekit_list_assets", "arguments": {"path": "/Game/../Other"}}},
    ]
    mcp = subprocess.run(
        [sys.executable, "-B", str(test_dir / "zonekit_mcp.py")],
        input="\n".join(map(json.dumps, requests)).encode() + b"\n",
        capture_output=True, check=True, timeout=12,
    )
    assert not mcp.stderr, mcp.stderr
    result = {msg["id"]: msg["result"] for msg in map(json.loads, mcp.stdout.splitlines())}
    assert result[1]["protocolVersion"] == "2025-06-18"
    assert {tool["name"] for tool in result[2]["tools"]} == {f"zonekit_{name}" for name in TOOLS}
    assert json.loads(result[3]["content"][0]["text"])["count"] == 1
    assert result[4]["isError"] is True
    worker.allow_writes = True
    state.pie = True
    try:
        call("set_point_light", edit)
    except BridgeError as error:
        assert "Play In Editor" in str(error)
    else:
        raise AssertionError("PIE session accepted a write")
    state.pie = False
    parent = "/Script/Engine.Actor"
    assert call("create_blueprint", {"asset": new_blueprint_path, "parent_class": parent})["parent_class"] == parent
    assert call("add_blueprint_function", {"asset": new_blueprint_path, "name": "UpdateLight"})["graph"] == "UpdateLight"
    assert call("add_blueprint_variable", {
        "asset": new_blueprint_path, "name": "CanGlow", "variable_type": "bool",
    })["variable"] == "CanGlow"
    default = {"asset": new_blueprint_path, "property_name": "initial_life_span"}
    assert call("get_blueprint_default", default)["value"] == 0
    assert call("set_blueprint_default", {**default, "value": 30})["value"] == 30
    try:
        call("import_graph_nodes", {"asset": new_blueprint_path, "graph": "EventGraph", "nodes_text": "example"})
    except BridgeError as error:
        assert "no native graph adapter" in str(error)
    else:
        raise AssertionError("Node import succeeded without a native adapter")
    native_result = {"success": True, "message": "Imported in adapter simulation", "nodes": ["AABB"]}
    def import_nodes(bp, graph, nodes_text):
        assert (bp, graph, nodes_text) == (assets[new_blueprint_path], "EventGraph", "example")
        return SimpleNamespace(get_editor_property=native_result.__getitem__)
    with_fake_editor.ZoneKitGraphLibrary = SimpleNamespace(import_nodes=import_nodes)
    assert call("graph_capabilities", {})["import_nodes"]
    assert call("import_graph_nodes", {
        "asset": new_blueprint_path, "graph": "EventGraph", "nodes_text": "example",
    })["nodes"] == ["AABB"]
    edited = call("set_point_light", edit)
    assert not edited["saved"] and edited["before"]["radius_cm"] == 500 and edited["after"]["radius_cm"] == 600
    assert light.edits == [("attenuation_radius", 600)] and not save_calls
    softened = call("set_point_light", {
        "asset": blueprint_path, "component": "BluePointLight",
        "source_radius_cm": 1.4, "soft_source_radius_cm": 3, "source_length_cm": 10,
        "cast_shadows": False, "specular_scale": 0.25,
    })
    assert softened["before"]["cast_shadows"] is True
    assert softened["after"]["cast_shadows"] is False
    assert softened["after"]["source_length_cm"] == 10
    assert softened["after"]["specular_scale"] == 0.25
    assert softened["after"]["inverse_squared_falloff"] and not softened["after"]["absolute_location"]
    assert call("compile_blueprint", {"asset": blueprint_path})["compile_invoked"]
    assert compile_calls == [blueprint]
    assert call("save_asset", {"asset": blueprint_path})["saved"] and save_calls == [blueprint]
    for invalid in (
        {**edit, "asset": "/Game/../Outside"},
        {**edit, "asset": blueprint_path + ".NotTheAsset"},
        {**edit, "radius_cm": float("nan")},
        {**edit, "radius_cm": True},
        {**edit, "radius_cm": 0},
    ):
        try:
            validate("set_point_light", invalid)
        except BridgeError:
            continue
        raise AssertionError(f"Invalid arguments accepted: {invalid}")
    assert not any(worker.inbox.glob("*.json")) and not any(worker.outbox.glob("*.json"))
    print("Passed MCP, cross-mount access, Blueprint creation, functions, variables, class defaults and edit gates.")
finally:
    done.set()
    thread.join()
