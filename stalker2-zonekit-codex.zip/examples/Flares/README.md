# Flares та ChemLight

`Flares.uplugin` і `Content/GameLite/GameData` містять опис мода та його конфігурацію. `Blueprints` містить текстові знімки активних редакторних асетів.

| Blueprint | Роль |
| --- | --- |
| `BP_ChemLightRuntime` | Підключає логіку мода до ігрового світу |
| `BP_ChemLightInput` | Обробляє активацію спорядженого ХІС |
| `BP_ChemLightProp` | Керує світлом і життєвим циклом палички |

Це вихідний приклад для Zone Kit. T3D-експорти можна читати, порівнювати й використовувати як довідку для відновлення графів. Для збирання ігрового мода потрібні власні модель, матеріали, іконка та асети UE. Посилання в CFG очікують `SK_ChemLight_Gilka` для моделі в руці і `SM_ChemLight` для моделі у світі.

[Скрипти авторингу й пакування](../../plugins/stalker2-modding/skills/stalker2-modding/scripts/zonekit-bridge/Flares/README.md)
