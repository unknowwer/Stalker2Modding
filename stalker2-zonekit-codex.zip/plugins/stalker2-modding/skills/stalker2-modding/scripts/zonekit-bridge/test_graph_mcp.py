"""Exercise the graph adapter through the local MCP server on an isolated asset."""

import argparse
import json
import sys

from zonekit_mcp import dispatch


ASSET = "/Flares/EditorTests/BP_ZoneKitGraphSmoke"
GRAPH = {"asset": ASSET, "graph": "EventGraph"}
MESSAGE = "Zone Kit MCP graph smoke test"
REQUIRED = ("inspect_nodes", "add_function_call", "ensure_event_override",
            "connect_pins", "set_pin_default", "compile_diagnostics")


def call(name, **arguments):
    reply = dispatch("tools/call", {"name": f"zonekit_{name}", "arguments": arguments})
    payload = json.loads(reply["content"][0]["text"])
    if reply["isError"]:
        raise RuntimeError(payload["error"])
    return payload


def find_member(nodes, name):
    matches = [node for node in nodes if node.get("member") == name]
    if len(matches) > 1:
        raise RuntimeError(f"Multiple {name} nodes in the scratch Blueprint")
    return matches[0] if matches else None


def find_pin(node, name, direction):
    return next(pin for pin in node["pins"] if pin["name"] == name and pin["direction"] == direction)


def test_graph(save):
    session = call("status")
    caps = call("graph_capabilities")
    listing = call("list_assets", path="/Flares/EditorTests", recursive=False)
    if f"{ASSET}.BP_ZoneKitGraphSmoke" not in listing["assets"]:
        call("create_blueprint", asset=ASSET, parent_class="/Script/Engine.Actor")
    blueprint = call("inspect_blueprint", asset=ASSET)
    missing = [name for name in REQUIRED if not caps.get(name)]
    if missing:
        inspection = (
            call("inspect_graph", **GRAPH)
            if caps.get("inspect_event_node_objects") or caps.get("inspect_nodes")
            else None
        )
        t3d = call("export_blueprint_t3d", asset=ASSET) if caps.get("export_blueprint_t3d") else None
        export = {"characters": t3d["total_characters"], "first_page_contains_pins":
                  "CustomProperties Pin" in t3d["text"]} if t3d else None
        return {"session": session, "blueprint": blueprint, "graph_inspection": inspection,
                "t3d_export": export,
                "compile": call("compile_blueprint", asset=ASSET), "missing_native_tools": missing,
                "graph_verified": False, "saved": False}

    nodes = call("inspect_graph", **GRAPH)["graph_nodes"]
    event = call("ensure_event_override", **GRAPH, event="ReceiveBeginPlay", x=0, y=0)["graph_nodes"][0]
    printer = find_member(nodes, "PrintString")
    if printer is None:
        printer = call("add_function_call", **GRAPH, owner_class="/Script/Engine.KismetSystemLibrary",
                       function="PrintString", x=320, y=0)["graph_nodes"][0]
    call("set_pin_default", **GRAPH, node=printer["guid"], pin="InString", value=MESSAGE)
    call("connect_graph_pins", **GRAPH, output_node=event["guid"], output_pin="then",
         input_node=printer["guid"], input_pin="execute")
    result = call("compile_blueprint", asset=ASSET)
    if result["compiler_status"] != "success" or result["error_count"]:
        return {"blueprint": blueprint, "compile": result, "graph_verified": False, "saved": False}

    nodes = call("inspect_graph", **GRAPH)["graph_nodes"]
    event = find_member(nodes, "ReceiveBeginPlay")
    printer = find_member(nodes, "PrintString")
    output = find_pin(event, "then", "out")
    entry = find_pin(printer, "execute", "in")
    message = find_pin(printer, "InString", "in")
    if (f'{printer["guid"]}.execute' not in output["links"] or
            f'{event["guid"]}.then' not in entry["links"] or message["default"] != MESSAGE):
        raise RuntimeError("The compiled graph did not retain the requested links and text")
    saved = call("save_asset", asset=ASSET)["saved"] if save else False
    return {"session": session, "blueprint": blueprint, "compile": result, "graph_verified": True,
            "event": event["guid"], "print_string": printer["guid"], "saved": saved}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--save", action="store_true", help="Save the scratch asset after full graph verification")
    args = parser.parse_args()
    try:
        result = test_graph(args.save)
    except (KeyError, RuntimeError, StopIteration) as error:
        parser.exit(1, f"MCP smoke test: {error}\n")
    print(json.dumps(result, ensure_ascii=True, indent=2))
    sys.exit(0 if result["graph_verified"] else 2)


if __name__ == "__main__":
    main()
