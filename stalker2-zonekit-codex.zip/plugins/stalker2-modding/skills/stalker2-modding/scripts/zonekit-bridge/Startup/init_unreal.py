"""Optional Zone Kit startup entry point, loaded via UE_PYTHONPATH."""

from pathlib import Path
import sys

import unreal


if unreal.SystemLibrary.get_game_name().casefold() == "stalker2":
    bridge_directory = str(Path(__file__).resolve().parent.parent)
    if bridge_directory not in sys.path:
        sys.path.insert(0, bridge_directory)
    from zonekit_bridge import start_editor

    start_editor(unreal)
