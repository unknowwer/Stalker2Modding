#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "ZoneKitGraphLibrary.generated.h"

class UBlueprint;

USTRUCT(BlueprintType)
struct FZoneKitGraphPin
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString Name;
    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString Direction;
    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString Category;
    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString DefaultValue;
    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    TArray<FString> Links;
};

USTRUCT(BlueprintType)
struct FZoneKitGraphNode
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString Guid;
    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString ClassName;
    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString MemberName;
    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    TArray<FZoneKitGraphPin> Pins;
};

USTRUCT(BlueprintType)
struct ZONEKITGRAPHADAPTER_API FZoneKitGraphResult
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    bool bSuccess = false;

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    FString Message;

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    TArray<FString> Nodes;

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    TArray<FZoneKitGraphNode> GraphNodes;

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    TArray<FString> Diagnostics;

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    int32 ErrorCount = 0;

    UPROPERTY(BlueprintReadOnly, Category = "Zone Kit Graph")
    int32 WarningCount = 0;
};

UCLASS()
class ZONEKITGRAPHADAPTER_API UZoneKitGraphLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Zone Kit Graph")
    static FZoneKitGraphResult DescribeNodes(UBlueprint* Blueprint, FName GraphName);

    UFUNCTION(BlueprintCallable, Category = "Zone Kit Graph")
    static FZoneKitGraphResult ImportNodes(UBlueprint* Blueprint, FName GraphName, const FString& NodeText);

    UFUNCTION(BlueprintCallable, Category = "Zone Kit Graph")
    static FZoneKitGraphResult AddFunctionCall(
        UBlueprint* Blueprint, FName GraphName, const FString& OwnerClass, FName FunctionName, int32 X, int32 Y);

    UFUNCTION(BlueprintCallable, Category = "Zone Kit Graph")
    static FZoneKitGraphResult EnsureEventOverride(
        UBlueprint* Blueprint, FName GraphName, FName EventName, int32 X, int32 Y);

    UFUNCTION(BlueprintCallable, Category = "Zone Kit Graph")
    static FZoneKitGraphResult SetPinDefault(
        UBlueprint* Blueprint, FName GraphName, const FString& Node, FName Pin, const FString& Value);

    UFUNCTION(BlueprintCallable, Category = "Zone Kit Graph")
    static FZoneKitGraphResult ConnectPins(
        UBlueprint* Blueprint, FName GraphName,
        const FString& OutputNode, FName OutputPin,
        const FString& InputNode, FName InputPin);

    UFUNCTION(BlueprintCallable, Category = "Zone Kit Graph")
    static FZoneKitGraphResult CompileWithDiagnostics(UBlueprint* Blueprint);
};
