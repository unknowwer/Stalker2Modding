#include "ZoneKitGraphLibrary.h"

#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphNode.h"
#include "EdGraph/EdGraphPin.h"
#include "EdGraph/EdGraphSchema.h"
#include "EdGraphSchema_K2.h"
#include "EdGraphUtilities.h"
#include "Engine/Blueprint.h"
#include "K2Node_CallFunction.h"
#include "K2Node_Event.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/CompilerResultsLog.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Logging/TokenizedMessage.h"
#include "Modules/ModuleManager.h"
#include "ScopedTransaction.h"
#include "UObject/UObjectGlobals.h"

IMPLEMENT_MODULE(FDefaultModuleImpl, ZoneKitGraphAdapter)

namespace
{
UEdGraph* FindK2Graph(UBlueprint* Blueprint, const FName GraphName)
{
    if (!IsValid(Blueprint))
    {
        return nullptr;
    }
    TArray<UEdGraph*> Graphs;
    Blueprint->GetAllGraphs(Graphs);
    UEdGraph* Match = nullptr;
    for (UEdGraph* Graph : Graphs)
    {
        if (IsValid(Graph) && Graph->GetFName() == GraphName && Cast<UEdGraphSchema_K2>(Graph->GetSchema()))
        {
            if (Match && Match != Graph)
            {
                return nullptr;
            }
            Match = Graph;
        }
    }
    return Match;
}

FZoneKitGraphResult Fail(const FString& Message)
{
    FZoneKitGraphResult Result;
    Result.Message = Message;
    return Result;
}

FString DescribeNode(const UEdGraphNode& Node)
{
    TArray<FString> Pins;
    for (const UEdGraphPin* Pin : Node.Pins)
    {
        if (Pin && !Pin->bOrphanedPin)
        {
            Pins.Add(FString::Printf(TEXT("%s:%s"),
                Pin->Direction == EGPD_Output ? TEXT("out") : TEXT("in"), *Pin->PinName.ToString()));
        }
    }
    return FString::Printf(TEXT("%s %s (%s)"),
        *Node.NodeGuid.ToString(EGuidFormats::Digits), *Node.GetClass()->GetName(),
        *FString::Join(Pins, TEXT(", ")));
}

void AddNodeDetails(FZoneKitGraphResult& Result, const UEdGraphNode& Node)
{
    Result.Nodes.Add(DescribeNode(Node));
    FZoneKitGraphNode& Data = Result.GraphNodes.AddDefaulted_GetRef();
    Data.Guid = Node.NodeGuid.ToString(EGuidFormats::Digits);
    Data.ClassName = Node.GetClass()->GetName();
    if (const UK2Node_Event* Event = Cast<UK2Node_Event>(&Node))
    {
        Data.MemberName = Event->EventReference.GetMemberName().ToString();
    }
    else if (const UK2Node_CallFunction* Call = Cast<UK2Node_CallFunction>(&Node))
    {
        Data.MemberName = Call->FunctionReference.GetMemberName().ToString();
    }
    for (const UEdGraphPin* Pin : Node.Pins)
    {
        if (!Pin || Pin->bOrphanedPin)
        {
            continue;
        }
        FZoneKitGraphPin& PinData = Data.Pins.AddDefaulted_GetRef();
        PinData.Name = Pin->PinName.ToString();
        PinData.Direction = Pin->Direction == EGPD_Output ? TEXT("out") : TEXT("in");
        PinData.Category = Pin->PinType.PinCategory.ToString();
        PinData.DefaultValue = Pin->GetDefaultAsString();
        for (const UEdGraphPin* Other : Pin->LinkedTo)
        {
            if (Other && Other->GetOwningNode())
            {
                PinData.Links.Add(Other->GetOwningNode()->NodeGuid.ToString(EGuidFormats::Digits)
                    + TEXT(".") + Other->PinName.ToString());
            }
        }
        PinData.Links.Sort();
    }
}

FZoneKitGraphResult NodeResult(const UEdGraphNode& Node, const FString& Message)
{
    FZoneKitGraphResult Result;
    Result.bSuccess = true;
    Result.Message = Message;
    AddNodeDetails(Result, Node);
    return Result;
}

void NotifyGraphEdit(UBlueprint* Blueprint, UEdGraph* Graph)
{
    Graph->NotifyGraphChanged();
    FBlueprintEditorUtils::MarkBlueprintAsModified(Blueprint);
}

UEdGraphPin* FindPin(UEdGraph& Graph, const FString& NodeId, const FName PinName, EEdGraphPinDirection Direction)
{
    FGuid Guid;
    if (!FGuid::ParseExact(NodeId, EGuidFormats::Digits, Guid))
    {
        return nullptr;
    }
    for (UEdGraphNode* Node : Graph.Nodes)
    {
        if (IsValid(Node) && Node->NodeGuid == Guid)
        {
            UEdGraphPin* Match = nullptr;
            for (UEdGraphPin* Pin : Node->Pins)
            {
                if (Pin && !Pin->bOrphanedPin && Pin->PinName == PinName && Pin->Direction == Direction)
                {
                    if (Match)
                    {
                        return nullptr;
                    }
                    Match = Pin;
                }
            }
            return Match;
        }
    }
    return nullptr;
}
}

FZoneKitGraphResult UZoneKitGraphLibrary::DescribeNodes(UBlueprint* Blueprint, FName GraphName)
{
    const UEdGraph* Graph = FindK2Graph(Blueprint, GraphName);
    if (!Graph)
    {
        return Fail(TEXT("K2 graph was not found"));
    }
    FZoneKitGraphResult Result;
    Result.bSuccess = true;
    Result.Message = FString::Printf(TEXT("%d nodes in graph"), Graph->Nodes.Num());
    for (const UEdGraphNode* Node : Graph->Nodes)
    {
        if (IsValid(Node))
        {
            AddNodeDetails(Result, *Node);
        }
    }
    return Result;
}

FZoneKitGraphResult UZoneKitGraphLibrary::ImportNodes(UBlueprint* Blueprint, FName GraphName, const FString& NodeText)
{
    UEdGraph* Graph = FindK2Graph(Blueprint, GraphName);
    if (!Graph || NodeText.IsEmpty() || NodeText.Len() > 128 * 1024
        || !FEdGraphUtilities::CanImportNodesFromText(Graph, NodeText))
    {
        return Fail(TEXT("The destination graph could not accept that node text"));
    }
    FScopedTransaction Transaction(NSLOCTEXT("ZoneKitGraphAdapter", "ImportNodes", "Import Blueprint nodes"));
    Blueprint->Modify();
    Graph->Modify();
    TSet<UEdGraphNode*> Imported;
    FEdGraphUtilities::ImportNodesFromText(Graph, NodeText, Imported);
    if (Imported.IsEmpty())
    {
        Transaction.Cancel();
        return Fail(TEXT("The import produced no nodes"));
    }
    FZoneKitGraphResult Result;
    Result.bSuccess = true;
    Result.Message = FString::Printf(TEXT("Imported %d nodes. Compile before saving."), Imported.Num());
    for (UEdGraphNode* Node : Imported)
    {
        if (IsValid(Node))
        {
            Node->CreateNewGuid();
            AddNodeDetails(Result, *Node);
        }
    }
    Graph->NotifyGraphChanged();
    FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
    return Result;
}

FZoneKitGraphResult UZoneKitGraphLibrary::AddFunctionCall(
    UBlueprint* Blueprint, FName GraphName, const FString& OwnerClass, FName FunctionName, int32 X, int32 Y)
{
    UEdGraph* Graph = FindK2Graph(Blueprint, GraphName);
    UClass* Owner = Graph ? FindObject<UClass>(nullptr, *OwnerClass) : nullptr;
    UFunction* Function = Owner ? Owner->FindFunctionByName(FunctionName) : nullptr;
    if (!Function || !Function->HasAnyFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintPure))
    {
        return Fail(TEXT("Expected a K2 graph and a loaded class with a Blueprint-callable function"));
    }
    const FScopedTransaction Transaction(NSLOCTEXT("ZoneKitGraphAdapter", "AddCall", "Add Blueprint call"));
    Blueprint->Modify();
    Graph->Modify();
    FGraphNodeCreator<UK2Node_CallFunction> Creator(*Graph);
    UK2Node_CallFunction* Node = Creator.CreateNode();
    Node->SetFromFunction(Function);
    Node->NodePosX = X;
    Node->NodePosY = Y;
    Creator.Finalize();
    NotifyGraphEdit(Blueprint, Graph);
    return NodeResult(*Node, TEXT("Added function call"));
}

FZoneKitGraphResult UZoneKitGraphLibrary::EnsureEventOverride(
    UBlueprint* Blueprint, FName GraphName, FName EventName, int32 X, int32 Y)
{
    UEdGraph* Graph = FindK2Graph(Blueprint, GraphName);
    UFunction* Function = Graph && Blueprint->ParentClass ? Blueprint->ParentClass->FindFunctionByName(EventName) : nullptr;
    if (!Function || !Function->HasAnyFunctionFlags(FUNC_BlueprintEvent) || Graph->GetSchema()->GetGraphType(Graph) != GT_Ubergraph)
    {
        return Fail(TEXT("Expected an event graph and an overridable Blueprint event from the parent class"));
    }
    TArray<UEdGraph*> Graphs;
    Blueprint->GetAllGraphs(Graphs);
    for (UEdGraph* Candidate : Graphs)
    {
        if (!Candidate)
        {
            continue;
        }
        for (UEdGraphNode* Node : Candidate->Nodes)
        {
            UK2Node_Event* Event = Cast<UK2Node_Event>(Node);
            if (Event && Event->bOverrideFunction && Event->EventReference.GetMemberName() == EventName)
            {
                if (Candidate != Graph)
                {
                    return Fail(TEXT("The event already belongs to another graph"));
                }
                if (Event->IsAutomaticallyPlacedGhostNode())
                {
                    const FScopedTransaction Transaction(NSLOCTEXT("ZoneKitGraphAdapter", "EnableEvent", "Enable default Blueprint event"));
                    Blueprint->Modify();
                    Graph->Modify();
                    Event->Modify();
                    Event->SetEnabledState(ENodeEnabledState::Enabled);
                    NotifyGraphEdit(Blueprint, Graph);
                }
                return NodeResult(*Event, TEXT("Found existing event override"));
            }
        }
    }
    const FScopedTransaction Transaction(NSLOCTEXT("ZoneKitGraphAdapter", "AddEvent", "Add Blueprint event override"));
    Blueprint->Modify();
    Graph->Modify();
    FGraphNodeCreator<UK2Node_Event> Creator(*Graph);
    UK2Node_Event* Node = Creator.CreateNode();
    Node->EventReference.SetExternalMember(EventName, Function->GetOwnerClass());
    Node->bOverrideFunction = true;
    Node->NodePosX = X;
    Node->NodePosY = Y;
    Creator.Finalize();
    NotifyGraphEdit(Blueprint, Graph);
    return NodeResult(*Node, TEXT("Added event override"));
}

FZoneKitGraphResult UZoneKitGraphLibrary::SetPinDefault(
    UBlueprint* Blueprint, FName GraphName, const FString& Node, FName Pin, const FString& Value)
{
    UEdGraph* Graph = FindK2Graph(Blueprint, GraphName);
    UEdGraphPin* Input = Graph ? FindPin(*Graph, Node, Pin, EGPD_Input) : nullptr;
    if (!Input || Input->bDefaultValueIsIgnored || Input->bDefaultValueIsReadOnly ||
        Input->PinType.PinCategory == UEdGraphSchema_K2::PC_Exec || !Input->LinkedTo.IsEmpty())
    {
        return Fail(TEXT("Expected a writable, unconnected input pin with a default value"));
    }
    const UEdGraphSchema* Schema = Graph->GetSchema();
    const FString Error = Schema->IsPinDefaultValid(Input, Value, nullptr, FText::GetEmpty());
    if (!Error.IsEmpty())
    {
        return Fail(Error);
    }
    UEdGraphNode* Owner = Input->GetOwningNode();
    const FScopedTransaction Transaction(NSLOCTEXT("ZoneKitGraphAdapter", "SetPinDefault", "Set Blueprint pin default"));
    Blueprint->Modify();
    Graph->Modify();
    Owner->Modify();
    Schema->TrySetDefaultValue(*Input, Value, true);
    NotifyGraphEdit(Blueprint, Graph);
    return NodeResult(*Owner, TEXT("Applied input pin default"));
}

FZoneKitGraphResult UZoneKitGraphLibrary::ConnectPins(
    UBlueprint* Blueprint, FName GraphName, const FString& OutputNode, FName OutputPin,
    const FString& InputNode, FName InputPin)
{
    UEdGraph* Graph = FindK2Graph(Blueprint, GraphName);
    if (!Graph)
    {
        return Fail(TEXT("K2 graph was not found"));
    }
    UEdGraphPin* From = FindPin(*Graph, OutputNode, OutputPin, EGPD_Output);
    UEdGraphPin* To = FindPin(*Graph, InputNode, InputPin, EGPD_Input);
    if (!From || !To || From->bOrphanedPin || To->bOrphanedPin)
    {
        return Fail(TEXT("A named pin was not found on the supplied node"));
    }
    if (From->LinkedTo.Contains(To) && To->LinkedTo.Contains(From))
    {
        return NodeResult(*From->GetOwningNode(), TEXT("Pins are already connected"));
    }
    const UEdGraphSchema* Schema = Graph->GetSchema();
    if (Schema->CanCreateConnection(From, To).Response != CONNECT_RESPONSE_MAKE)
    {
        return Fail(TEXT("The schema rejected a direct link or requires replacing a link or adding a conversion"));
    }
    FScopedTransaction Transaction(NSLOCTEXT("ZoneKitGraphAdapter", "ConnectPins", "Connect Blueprint pins"));
    Blueprint->Modify();
    Graph->Modify();
    From->GetOwningNode()->Modify();
    To->GetOwningNode()->Modify();
    if (!Schema->TryCreateConnection(From, To))
    {
        Transaction.Cancel();
        return Fail(TEXT("The schema did not create the link"));
    }
    NotifyGraphEdit(Blueprint, Graph);
    return NodeResult(*From->GetOwningNode(), TEXT("Connected pins. Compile before saving."));
}

FZoneKitGraphResult UZoneKitGraphLibrary::CompileWithDiagnostics(UBlueprint* Blueprint)
{
    if (!IsValid(Blueprint))
    {
        return Fail(TEXT("Blueprint was not found"));
    }
    FCompilerResultsLog Log;
    FKismetEditorUtilities::CompileBlueprint(Blueprint, EBlueprintCompileOptions::None, &Log);
    FZoneKitGraphResult Result;
    Result.ErrorCount = Log.NumErrors;
    Result.WarningCount = Log.NumWarnings;
    for (const auto& Message : Log.Messages)
    {
        Result.Diagnostics.Add(Message->ToText().ToString());
    }
    Result.bSuccess = Log.NumErrors == 0 && Blueprint->Status != BS_Error;
    Result.Message = Result.bSuccess ? TEXT("Blueprint compiled") : TEXT("Blueprint compilation failed");
    return Result;
}
