$ErrorActionPreference = 'Stop'

$zoneKit = if ($env:STALKER2_ZONE_KIT) {
    $env:STALKER2_ZONE_KIT
} else {
    Join-Path $env:ProgramFiles 'STALKER2ZoneKit'
}
$python = Join-Path $zoneKit 'Engine\Binaries\ThirdParty\Python3\Win64\python.exe'
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    [Console]::Error.WriteLine("Zone Kit Python was not found. Set STALKER2_ZONE_KIT to the Zone Kit installation directory.")
    exit 1
}
& $python -B (Join-Path $PSScriptRoot 'zonekit_mcp.py')
exit $LASTEXITCODE
