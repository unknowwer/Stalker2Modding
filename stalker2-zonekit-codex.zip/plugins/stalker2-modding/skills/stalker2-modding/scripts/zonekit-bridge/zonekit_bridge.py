"""Editor-side worker and local transport for the Zone Kit extension.

Run this file in the Zone Kit Python console. Outside Zone Kit it acts as a
command-line client. It requires only the Python standard library.
"""

import argparse
import builtins
import importlib
import json
import os
from pathlib import Path
import re
import sys
import time
from uuid import uuid4


BRIDGE_DIR = Path(__file__).resolve().parent
# Zone Kit's Python console can execute a script without adding its directory.
if str(BRIDGE_DIR) not in sys.path:
    sys.path.insert(0, str(BRIDGE_DIR))

import zonekit_tools
from zonekit_tools import BridgeError, DEFAULT_PATH, TOOLS, validate


DEFAULT_HOME = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Stalker2ZoneKitCodex"
BRIDGE_HOME = Path(os.environ.get("ZONEKIT_MCP_HOME", DEFAULT_HOME)).resolve()
ROOT = BRIDGE_HOME / "exchange"
SETTINGS = BRIDGE_HOME / "bridge_settings.json"
VERSION = 3
MAX_REQUEST = 1024 * 1024
REQUEST_ID = re.compile(r"[0-9a-f]{32}\Z")
WORKER_KEY = "_flares_file_bridge_worker"


def write_json(path, value):
    temporary = path.with_name(f".{path.name}.{uuid4().hex}.tmp")
    try:
        temporary.write_text(json.dumps(value, ensure_ascii=False) + "\n", encoding="utf-8")
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)


def read_json(path, limit=MAX_REQUEST):
    with path.open("rb") as stream:
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise BridgeError("JSON message is too large")
    value = json.loads(data)
    if not isinstance(value, dict):
        raise BridgeError("Expected a JSON object")
    return value


def load_settings():
    if not SETTINGS.is_file():
        return {}
    settings = read_json(SETTINGS)
    if settings.keys() - {"allow_writes"} or type(settings.get("allow_writes", False)) is not bool:
        raise BridgeError("bridge_settings.json expects a boolean allow_writes setting")
    return settings


class EditorWorker:
    def __init__(self, unreal, root, *, allow_writes=False):
        self.unreal = unreal
        self.root = root
        self.session = uuid4().hex
        self.inbox = root / "requests" / self.session
        self.outbox = root / "responses" / self.session
        self.inbox.mkdir(parents=True)
        self.outbox.mkdir(parents=True)
        self.last_poll = 0.0
        self.last_heartbeat = 0.0
        self.tick_handle = None
        self.allow_writes = allow_writes
        self.pending_response = None

    def start(self):
        self.heartbeat()
        self.tick_handle = self.unreal.register_slate_post_tick_callback(self.tick)
        mode = "editing enabled" if self.allow_writes else "read-only"
        self.unreal.log(f"FlaresBridge ready ({mode}). Exchange: {self.root}")

    def stop(self):
        if self.tick_handle is not None:
            self.unreal.unregister_slate_post_tick_callback(self.tick_handle)
            self.tick_handle = None
        if getattr(builtins, WORKER_KEY, None) is self:
            delattr(builtins, WORKER_KEY)

    def heartbeat(self):
        write_json(self.root / "session.json", {
            "version": VERSION,
            "session": self.session,
            "pid": os.getpid(),
            "heartbeat": time.time(),
        })
        self.last_heartbeat = time.monotonic()

    def tick(self, _delta_seconds):
        now = time.monotonic()
        if now - self.last_poll < 0.25:
            return
        self.last_poll = now
        try:
            if now - self.last_heartbeat >= 2:
                self.heartbeat()
            if self.pending_response is not None:
                # A busy Windows filesystem can delay replies. Never run an edit twice.
                self.publish_response()
                return
            # Consume a single request per tick. UE calls stay on the editor thread.
            request = next((p for p in self.inbox.glob("*.json") if REQUEST_ID.fullmatch(p.stem)), None)
            if request is not None:
                self.process(request)
        except OSError:
            # A file can be temporarily held open by another Windows process.
            # The next tick can retry without changing any editor assets.
            return

    def process(self, request):
        response = self.outbox / request.name
        if response.exists():
            request.unlink(missing_ok=True)
            return
        try:
            payload = read_json(request)
        except OSError:
            raise
        except (ValueError, BridgeError) as error:
            self.pending_response = (request, response, {
                "id": request.stem, "session": self.session, "ok": False, "error": str(error),
            })
            self.publish_response()
            return
        try:
            if payload.get("session") != self.session or payload.get("id") != request.stem:
                raise BridgeError("Request belongs to a different session or ID")
            expiry = payload.get("expires")
            if type(expiry) not in (int, float) or not time.time() < expiry <= time.time() + 60:
                raise BridgeError("Request expired or has an invalid deadline")
            operation = payload.get("operation")
            arguments = validate(operation, payload.get("arguments"))
            result = {"ok": True, "result": self.execute(operation, arguments)}
        except Exception as error:
            result = {"ok": False, "error": str(error)}
        self.pending_response = (request, response, {"id": request.stem, "session": self.session, **result})
        self.publish_response()

    def publish_response(self):
        request, response, payload = self.pending_response
        request.unlink(missing_ok=True)
        try:
            encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
            if len(encoded) > 240 * 1024:
                raise ValueError("Result exceeds the response limit")
        except (ValueError, TypeError) as error:
            payload = {"id": request.stem, "session": self.session, "ok": False,
                       "error": f"Tool returned an invalid JSON result: {error}"}
        write_json(response, payload)
        self.pending_response = None

    def execute(self, operation, arguments):
        tool = TOOLS[operation]
        if not tool.read_only:
            if not self.allow_writes:
                raise BridgeError("This Zone Kit session is read-only")
            level_library = getattr(self.unreal, "EditorLevelLibrary", None)
            if level_library is None or level_library.get_pie_worlds(True):
                raise BridgeError("End Play In Editor before editing assets")
        return tool.action(self, **arguments)

    def status(self):
        unreal = self.unreal
        assets = unreal.EditorAssetLibrary
        return {
            "session": self.session,
            "editor_pid": os.getpid(),
            "engine_version": unreal.SystemLibrary.get_engine_version(),
            "project": unreal.SystemLibrary.get_game_name(),
            "asset_scope": "all_editor_mounts",
            "flares_registered": assets.does_asset_exist("/Flares/Flares"),
            "asset_registry_loading": unreal.AssetRegistryHelpers.get_asset_registry().is_loading_assets(),
            "writes_enabled": self.allow_writes,
        }


def start_editor(unreal):
    global BridgeError, TOOLS, validate
    if unreal.SystemLibrary.get_game_name().casefold() != "stalker2":
        raise BridgeError("FlaresBridge requires the Stalker2 Zone Kit project")
    settings = load_settings()
    previous = getattr(builtins, WORKER_KEY, None)
    if previous is not None:
        previous.stop()
    importlib.reload(zonekit_tools)
    BridgeError, TOOLS, validate = zonekit_tools.BridgeError, zonekit_tools.TOOLS, zonekit_tools.validate
    worker = EditorWorker(unreal, ROOT, **settings)
    worker.start()
    setattr(builtins, WORKER_KEY, worker)


def call(operation, arguments, root=ROOT, timeout=15.0):
    arguments = validate(operation, arguments)
    try:
        state = read_json(root / "session.json")
    except FileNotFoundError:
        raise BridgeError("Run zonekit_bridge.py in the Zone Kit Python console first") from None
    session = state.get("session")
    heartbeat = state.get("heartbeat")
    if state.get("version") != VERSION or not isinstance(session, str) or not REQUEST_ID.fullmatch(session):
        raise BridgeError("Start the current zonekit_bridge.py in Zone Kit to update the editor session")
    if type(heartbeat) not in (int, float) or not 0 <= time.time() - heartbeat < 12:
        raise BridgeError("Zone Kit is closed, busy, or the bridge is paused")
    request_id = uuid4().hex
    request = root / "requests" / session / f"{request_id}.json"
    response = root / "responses" / session / f"{request_id}.json"
    payload = {
        "id": request_id, "session": session, "operation": operation,
        "arguments": arguments, "expires": time.time() + timeout,
    }
    if len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) + 1 > MAX_REQUEST:
        raise BridgeError("Tool request is too large")
    write_json(request, payload)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            payload = read_json(response, limit=256 * 1024)
        except FileNotFoundError:
            time.sleep(0.1)
            continue
        response.unlink(missing_ok=True)
        if payload.get("id") != request_id or payload.get("session") != session:
            raise BridgeError("Unexpected Zone Kit response identity")
        if payload.get("ok") is True:
            return payload["result"]
        raise BridgeError(payload.get("error", "Zone Kit request failed"))
    request.unlink(missing_ok=True)
    raise BridgeError("Zone Kit did not answer before the deadline")


def cli():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="operation", required=True)
    commands.add_parser("status")
    listing = commands.add_parser("list_assets")
    listing.add_argument("--path", default=DEFAULT_PATH)
    listing.add_argument("--recursive", action="store_true")
    inspect = commands.add_parser("inspect_blueprint")
    inspect.add_argument("asset")
    values = vars(parser.parse_args())
    operation = values.pop("operation")
    try:
        print(json.dumps(call(operation, values), ensure_ascii=True, indent=2))
    except (BridgeError, OSError, ValueError) as error:
        parser.exit(1, f"FlaresBridge: {error}\n")


if __name__ == "__main__":
    try:
        import unreal
    except ModuleNotFoundError:
        cli()
    else:
        start_editor(unreal)
