"""Bind the original ChemLight geometry to the exported Gilka armature in Blender."""

import json
from pathlib import Path
import sys

import bpy
from mathutils import Matrix, Quaternion, Vector


def import_fbx(filename):
    existing = set(bpy.data.objects)
    bpy.ops.import_scene.fbx(filepath=str(filename))
    return set(bpy.data.objects) - existing


def make_gilka_armature(reference_bones):
    armature = bpy.data.armatures.new("GilkaRestPose")
    rig = bpy.data.objects.new("Armature", armature)
    bpy.context.scene.collection.objects.link(rig)
    bpy.context.view_layer.objects.active = rig
    rig.select_set(True)
    bpy.ops.object.mode_set(mode="EDIT")

    # Unreal uses centimeters and a left-handed frame. Convert each local pose
    # before composing it with its parent's component-space transform.
    handedness = Matrix.Diagonal((1, -1, 1, 1))
    poses = {}
    for reference in reference_bones:
        name = reference["name"]
        parent_name = reference["parent"]
        x, y, z, w = reference["rotation_xyzw"]
        location = Vector(reference["location_cm"]) * 0.01
        unreal_pose = Matrix.LocRotScale(location, Quaternion((w, x, y, z)), Vector(reference["scale"]))
        local_pose = handedness @ unreal_pose @ handedness
        pose = poses.get(parent_name, Matrix.Identity(4)) @ local_pose

        bone = armature.edit_bones.new(name)
        bone.tail = (0, 0.02, 0)
        bone.parent = armature.edit_bones.get(parent_name)
        bone.matrix = pose
        poses[name] = pose

    bpy.ops.object.mode_set(mode="OBJECT")
    return rig


def main():
    source, rig_source, output = map(Path, sys.argv[sys.argv.index("--") + 1:])
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)

    mesh, = (obj for obj in import_fbx(source) if obj.type == "MESH")
    reference_bones = json.loads(rig_source.read_text(encoding="utf-8"))["gilka"]["bones"]
    rig = make_gilka_armature(reference_bones)
    if rig.data.bones.get("jnt_offset") is None:
        raise RuntimeError("The reference armature is missing the main detector bone")

    # Keep the bone hierarchy and rest pose. Only the original ChemLight is exported.
    mesh.name = "ChemLight"
    mesh_transform = mesh.matrix_world.copy()
    mesh.parent = rig
    mesh.matrix_world = mesh_transform
    weights = mesh.vertex_groups.new(name="jnt_offset")
    weights.add([vertex.index for vertex in mesh.data.vertices], 1.0, "REPLACE")
    mesh.modifiers.new(name="Gilka Rig", type="ARMATURE").object = rig

    bpy.ops.object.select_all(action="DESELECT")
    rig.select_set(True)
    mesh.select_set(True)
    bpy.context.view_layer.objects.active = rig
    bpy.context.scene.unit_settings.system = "METRIC"
    bpy.context.scene.unit_settings.scale_length = 1.0
    bpy.ops.export_scene.fbx(
        filepath=str(output), use_selection=True, object_types={"MESH", "ARMATURE"},
        apply_unit_scale=True, apply_scale_options="FBX_SCALE_NONE",
        axis_forward="-Y", axis_up="Z", bake_anim=False, add_leaf_bones=False,
        use_armature_deform_only=False, path_mode="STRIP",
    )
    print(f"Exported {mesh.name} with {len(rig.data.bones)} Gilka bones to {output}")


if __name__ == "__main__":
    main()
