"""Create the ChemLight preview actor and inspect the stock Gilka rig in Zone Kit.

This script owns one Blueprint in /Flares/ChemLight. It adds the visual pieces
for the gameplay graph and exports the rig metadata needed to author the hold.
"""

import json
from pathlib import Path

import unreal


CHEMLIGHT = "/Flares/ChemLight"
PREVIEW_ASSET = f"{CHEMLIGHT}/BP_ChemLightProp"
GILKA_MESH = "/Game/_STALKER2/SkeletalMeshes/weapons/items/detector/SK_detector"
GILKA_ANIM = "/Game/_STALKER2/Animations/Weapons/items/detectors/gilka/AnimBP_Gilka"
BLUE_COLOR = unreal.Color(r=38, g=115, b=255, a=255)
LIGHT_PRESET = Path(__file__).with_name("ChemLightPointLight.json")
REPORT = Path(__file__).resolve().parent / "chemlight-gilka-probe.json"


def mesh_rig(mesh):
    skeleton = mesh.get_editor_property("skeleton")
    component = unreal.new_object(unreal.SkeletalMeshComponent)
    component.set_skinned_asset_and_update(mesh)
    bones = []
    for index in range(component.get_num_bones()):
        name = component.get_bone_name(index)
        pose = component.get_ref_pose_transform(index)
        bones.append({
            "name": str(name),
            "parent": str(component.get_parent_bone(name)),
            "location_cm": [pose.translation.x, pose.translation.y, pose.translation.z],
            "rotation_xyzw": [pose.rotation.x, pose.rotation.y, pose.rotation.z, pose.rotation.w],
            "scale": [pose.scale3d.x, pose.scale3d.y, pose.scale3d.z],
        })
    return {"mesh": mesh.get_path_name(), "skeleton": skeleton.get_path_name(), "bones": bones}


def new_component(blueprint, label, component_class):
    subsystem = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
    library = unreal.SubobjectDataBlueprintFunctionLibrary
    handles = subsystem.k2_gather_subobject_data_for_blueprint(blueprint)
    for handle in handles:
        data = subsystem.k2_find_subobject_data_from_handle(handle)
        if data is not None and str(library.get_variable_name(data)) == label:
            component = library.get_object_for_blueprint(data, blueprint)
            if isinstance(component, component_class):
                return component
            raise RuntimeError(f"{label} exists with an unexpected type")

    handle, reason = subsystem.add_new_subobject(unreal.AddNewSubobjectParams(
        parent_handle=handles[0], new_class=component_class, blueprint_context=blueprint,
    ))
    data = subsystem.k2_find_subobject_data_from_handle(handle)
    if data is None:
        raise RuntimeError(f"Could not add {label}: {reason}")
    subsystem.rename_subobject(handle, unreal.Text(label))
    return library.get_object_for_blueprint(data, blueprint)


def configure_preview_actor(mesh):
    assets = unreal.EditorAssetLibrary
    editor = unreal.BlueprintEditorLibrary
    if assets.does_asset_exist(PREVIEW_ASSET):
        blueprint = assets.load_asset(PREVIEW_ASSET)
    else:
        blueprint = editor.create_blueprint_asset_with_parent(PREVIEW_ASSET, unreal.Actor)
    if blueprint is None:
        raise RuntimeError(f"Could not create {PREVIEW_ASSET}")

    prop = new_component(blueprint, "ChemLightMesh", unreal.StaticMeshComponent)
    prop.set_editor_property("mobility", unreal.ComponentMobility.MOVABLE)
    prop.set_editor_property("static_mesh", mesh)
    prop.set_collision_profile_name("NoCollision")

    light = new_component(blueprint, "BluePointLight", unreal.PointLightComponent)
    lighting = json.loads(LIGHT_PRESET.read_text(encoding="utf-8"))
    light.set_editor_property("mobility", unreal.ComponentMobility.MOVABLE)
    light.set_editor_property("intensity_units", unreal.LightUnits.CANDELAS)
    light.set_editor_property("intensity", lighting["intensity"])
    light.set_editor_property("light_color", BLUE_COLOR)
    light.set_editor_property("attenuation_radius", lighting["radius_cm"])
    light.set_editor_property("source_radius", lighting["source_radius_cm"])
    light.set_editor_property("soft_source_radius", lighting["soft_source_radius_cm"])
    light.set_editor_property("source_length", lighting["source_length_cm"])
    light.set_editor_property("cast_shadows", lighting["cast_shadows"])
    light.set_editor_property("specular_scale", lighting["specular_scale"])
    light.set_editor_property("use_temperature", False)
    # The held item starts dormant. The gameplay graph will enable the light.
    light.set_visibility(False)

    editor.compile_blueprint(blueprint)
    if not assets.save_loaded_asset(blueprint, only_if_is_dirty=False):
        raise RuntimeError(f"Could not save {PREVIEW_ASSET}")
    return {"blueprint": blueprint.get_path_name(), "light_intensity_cd": lighting["intensity"],
            "light_radius_cm": lighting["radius_cm"]}


def main():
    assets = unreal.EditorAssetLibrary
    world_mesh = assets.load_asset(f"{CHEMLIGHT}/SM_ChemLight")
    hand_mesh = assets.load_asset(f"{CHEMLIGHT}/SK_ChemLight_Gilka")
    if world_mesh is None or hand_mesh is None:
        raise RuntimeError("Select the Flares mod and check that both ChemLight meshes are present")

    result = {"preview": configure_preview_actor(world_mesh)}
    try:
        gilka = assets.load_asset(GILKA_MESH)
        anim = assets.load_asset(GILKA_ANIM)
        if gilka is None or anim is None:
            raise RuntimeError("Zone Kit did not load the stock Gilka skeletal mesh or Anim Blueprint")
        result["gilka"] = mesh_rig(gilka)
        result["chemlight"] = mesh_rig(hand_mesh)
        result["gilka_animation_blueprint"] = anim.get_path_name()
    except Exception as error:
        result["rig_probe_error"] = str(error)
        unreal.log_warning(f"ChemLight rig probe: {error}")

    REPORT.parent.mkdir(parents=True, exist_ok=True)
    REPORT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    unreal.log(f"ChemLight preview and Gilka probe written to {REPORT}")


if __name__ == "__main__":
    main()
