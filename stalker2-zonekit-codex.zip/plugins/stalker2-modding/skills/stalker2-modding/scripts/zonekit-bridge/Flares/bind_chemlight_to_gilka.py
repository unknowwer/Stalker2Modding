"""Import the original ChemLight geometry with the stock Gilka skeleton."""

import json
from pathlib import Path

import unreal


CHEMLIGHT = "/Flares/ChemLight"
TARGET = f"{CHEMLIGHT}/SK_ChemLight_Gilka"
GILKA_SKELETON = "/Game/_STALKER2/SkeletalMeshes/weapons/items/detector/SKEL_detector"
GRIP_BONE = "jnt_offset"
HAND_BONE = "jnt_l_hand"
SOURCE_FBX = Path(__file__).with_name("SK_ChemLight_Gilka.fbx")
REPORT = Path(__file__).resolve().parent / "chemlight-gilka-binding.json"


def require_asset(path, expected_type):
    asset = unreal.EditorAssetLibrary.load_asset(path)
    if not isinstance(asset, expected_type):
        raise RuntimeError(f"Could not load {path} as {expected_type.__name__}")
    return asset


def import_held_mesh(skeleton):
    if not SOURCE_FBX.is_file():
        raise FileNotFoundError(SOURCE_FBX)
    options = unreal.FbxImportUI()
    options.automated_import_should_detect_type = False
    options.import_as_skeletal = True
    options.mesh_type_to_import = unreal.FBXImportType.FBXIT_SKELETAL_MESH
    options.skeleton = skeleton
    options.import_materials = False
    options.import_textures = False
    options.import_animations = False
    options.create_physics_asset = False

    task = unreal.AssetImportTask()
    task.filename = str(SOURCE_FBX)
    task.destination_path = CHEMLIGHT
    task.destination_name = SOURCE_FBX.stem
    task.factory = unreal.FbxFactory()
    task.options = options
    task.automated = True
    unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
    return require_asset(TARGET, unreal.SkeletalMesh)


def assign_materials(held, source):
    source_materials = {
        str(slot.get_editor_property("material_slot_name")): slot.get_editor_property("material_interface")
        for slot in source.get_editor_property("static_materials")
    }
    slots = held.get_editor_property("materials")
    for slot in slots:
        name = str(slot.get_editor_property("imported_material_slot_name"))
        if name not in source_materials:
            raise RuntimeError(f"Unexpected ChemLight material slot {name}")
        slot.set_editor_property("material_interface", source_materials[name])
    held.set_editor_property("materials", slots)


def verify_and_save(held, skeleton):
    bound_skeleton = held.get_editor_property("skeleton")
    if bound_skeleton.get_path_name() != skeleton.get_path_name():
        raise RuntimeError("The new mesh is not bound to the stock Gilka skeleton")
    component = unreal.new_object(unreal.SkeletalMeshComponent)
    component.set_skinned_asset_and_update(held)
    for bone in (GRIP_BONE, HAND_BONE):
        if component.get_bone_index(bone) < 0:
            raise RuntimeError(f"The binding is missing {bone}")
    if not unreal.EditorAssetLibrary.save_loaded_asset(held, only_if_is_dirty=False):
        raise RuntimeError(f"Could not save {TARGET}")
    return {
        "mesh": held.get_path_name(),
        "skeleton": bound_skeleton.get_path_name(),
        "hand_bone": HAND_BONE,
        "body_bone": GRIP_BONE,
        "bone_count": component.get_num_bones(),
    }


def main():
    assets = unreal.EditorAssetLibrary
    source = require_asset(f"{CHEMLIGHT}/SM_ChemLight", unreal.StaticMesh)
    skeleton = require_asset(GILKA_SKELETON, unreal.Skeleton)
    if assets.does_asset_exist(TARGET):
        held = require_asset(TARGET, unreal.SkeletalMesh)
    else:
        held = import_held_mesh(skeleton)
    assign_materials(held, source)
    result = verify_and_save(held, skeleton)
    REPORT.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    unreal.log(f"ChemLight hand mesh saved on the Gilka rig: {held.get_path_name()}")


if __name__ == "__main__":
    main()
