"""Prepare the ChemLight prop for its lifecycle graph in Zone Kit."""

import unreal


PROP_PATH = "/Flares/ChemLight/BP_ChemLightProp"
STATE_VARIABLES = ("HasActivated", "ReadyToThrow")


def use_mesh_as_root(blueprint):
    # Physics moves the root so the actor follows the thrown mesh.
    subobjects = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
    library = unreal.SubobjectDataBlueprintFunctionLibrary
    handles = subobjects.k2_gather_subobject_data_for_blueprint(blueprint)
    for handle in handles:
        data = subobjects.k2_find_subobject_data_from_handle(handle)
        if str(library.get_variable_name(data)) != "ChemLightMesh":
            continue
        if library.is_root_component(data):
            return
        if not subobjects.make_new_scene_root(handles[0], handle, blueprint):
            raise RuntimeError("Could not use ChemLightMesh as the actor root")
        return
    raise RuntimeError("ChemLightMesh is missing from BP_ChemLightProp")


def add_state_variables(blueprint):
    editor = unreal.BlueprintEditorLibrary
    boolean_pin = editor.get_basic_type_by_name("bool")
    default_object = unreal.get_default_object(blueprint.generated_class())

    for name in STATE_VARIABLES:
        try:
            existing_value = default_object.get_editor_property(name)
        except Exception:
            if not editor.add_member_variable(blueprint, name, boolean_pin):
                raise RuntimeError(f"Could not add the Boolean variable {name}")
        else:
            if not isinstance(existing_value, bool):
                raise RuntimeError(f"Expected an existing Boolean variable named {name}")


def main():
    assets = unreal.EditorAssetLibrary
    blueprint = assets.load_asset(PROP_PATH)
    if not isinstance(blueprint, unreal.Blueprint):
        raise RuntimeError(f"Could not load {PROP_PATH}")

    use_mesh_as_root(blueprint)
    add_state_variables(blueprint)
    unreal.BlueprintEditorLibrary.compile_blueprint(blueprint)
    if not assets.save_loaded_asset(blueprint, only_if_is_dirty=False):
        raise RuntimeError(f"Could not save {PROP_PATH}")
    unreal.log("ChemLight prop is ready for the lifecycle Blueprint nodes")


if __name__ == "__main__":
    main()
