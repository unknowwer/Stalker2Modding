"""Export the ChemLight prop's activation, expiry and disposal Blueprint nodes."""

from dataclasses import dataclass, field
from pathlib import Path
from uuid import uuid4


OUTPUT = Path(__file__).with_name("ChemLightLifecycle.t3d")
BURN_TIME = "60.0"
BLUE_EMISSION = "6.0"


def quoted(value):
    return '"' + str(value).replace('\\', '\\\\').replace('"', '\\"') + '"'


def object_type(name):
    return f'PinCategory="object",PinSubCategoryObject="/Script/CoreUObject.Class\'/Script/Engine.{name}\'"'


VECTOR = (
    'PinCategory="struct",'
    'PinSubCategoryObject="/Script/CoreUObject.ScriptStruct\'/Script/CoreUObject.Vector\'"'
)


@dataclass
class Pin:
    node: str
    name: str
    kind: str
    is_output: bool = False
    default: str | None = None
    id: str = field(default_factory=lambda: uuid4().hex.upper())
    links: list = field(default_factory=list)

    def render(self):
        kind = self.kind if "=" in self.kind else f'PinCategory={quoted(self.kind)}'
        fields = [f"PinId={self.id}", f"PinName={quoted(self.name)}"]
        if self.is_output:
            fields.append('Direction="EGPD_Output"')
        fields.append(f"PinType.{kind.replace(',PinSubCategory', ',PinType.PinSubCategory')}")
        if self.default is not None:
            fields.append(f"DefaultValue={quoted(self.default)}")
        if self.links:
            targets = ",".join(f"{pin.node} {pin.id}" for pin in self.links)
            fields.append(f"LinkedTo=({targets},)")
        return f"   CustomProperties Pin ({','.join(fields)},)"


@dataclass
class Node:
    name: str
    node_class: str
    x: int
    y: int
    properties: list = field(default_factory=list)
    pins: dict = field(default_factory=dict)

    def pin(self, name, kind, output=False, default=None):
        self.pins[name] = Pin(self.name, name, kind, output, default)
        return self

    def render(self):
        return "\n".join([
            f"Begin Object Class={self.node_class} Name={quoted(self.name)}",
            *[f"   {prop}" for prop in self.properties],
            f"   NodePosX={self.x}", f"   NodePosY={self.y}",
            f"   NodeGuid={uuid4().hex.upper()}",
            *[pin.render() for pin in self.pins.values()], "End Object",
        ])


class Graph:
    def __init__(self):
        self.nodes = []

    def node(self, name, kind, x, y, *properties):
        node = Node(name, f"/Script/BlueprintGraph.K2Node_{kind}", x, y, list(properties))
        self.nodes.append(node)
        return node

    def note(self, name, label, x, y, width, height):
        note = Node(name, "/Script/UnrealEd.EdGraphNode_Comment", x, y, [
            f"NodeComment={quoted(label)}", f"NodeWidth={width}", f"NodeHeight={height}",
            "CommentColor=(R=0.08,G=0.25,B=0.5,A=1.0)",
        ])
        self.nodes.append(note)

    def event(self, name, x, y, vector_input=None):
        event = self.node(name, "CustomEvent", x, y, f'CustomFunctionName={quoted(name)}')
        if vector_input:
            event.properties.append(
                f'CustomProperties UserDefinedPin (PinName={quoted(vector_input)},'
                f'PinType=({VECTOR}),DesiredPinDirection=EGPD_Output)'
            )
            event.pin(vector_input, VECTOR, output=True)
        return event.pin("then", "exec", output=True)

    def function(self, name, owner, member, x, y, owner_pin=True):
        reference = "bSelfContext=True,"
        if owner_pin:
            reference = f'MemberParent="/Script/CoreUObject.Class\'/Script/Engine.{owner}\'",'
        node = self.node(name, "CallFunction", x, y, f'FunctionReference=({reference}MemberName={quoted(member)})')
        node.pin("execute", "exec").pin("then", "exec", output=True)
        if owner_pin:
            node.pin("self", object_type(owner))
        return node

    def get(self, name, member, kind, x, y):
        reference = f'VariableReference=(MemberName={quoted(member)},bSelfContext=True)'
        node = self.node(name, "VariableGet", x, y, reference)
        return node.pin(member, kind, output=True)

    def set_flag(self, name, member, value, x, y):
        reference = f'VariableReference=(MemberName={quoted(member)},bSelfContext=True)'
        node = self.node(name, "VariableSet", x, y, reference)
        node.pin("execute", "exec")
        node.pin("then", "exec", output=True)
        return node.pin(member, "bool", default=value)

    def branch(self, name, x, y):
        return self.node(name, "IfThenElse", x, y).pin("execute", "exec").pin("Condition", "bool").pin(
            "then", "exec", output=True).pin("else", "exec", output=True)

    @staticmethod
    def link(source, source_pin, target, target_pin):
        outgoing = source.pins[source_pin]
        incoming = target.pins[target_pin]
        assert outgoing.is_output and not incoming.is_output
        outgoing.links.append(incoming)
        incoming.links.append(outgoing)

    def chain(self, *nodes):
        for left, right in zip(nodes, nodes[1:]):
            self.link(left, "then", right, "execute")


LIGHT = "BluePointLight"
MESH = "ChemLightMesh"
STARTED = "HasActivated"
DISPOSABLE = "ReadyToThrow"


def set_light_visibility(graph, name, enabled, x, y):
    call = graph.function(name, "SceneComponent", "SetVisibility", x, y)
    call.pin("bNewVisibility", "bool", default=enabled).pin("bPropagateToChildren", "bool", default="false")
    component = graph.get(f"{name}_Component", LIGHT, object_type("PointLightComponent"), x, y + 180)
    graph.link(component, LIGHT, call, "self")
    return call


def set_tube_emission(graph, name, strength, x, y):
    call = graph.function(name, "MeshComponent", "SetScalarParameterValueOnMaterials", x, y)
    call.pin("ParameterName", "name", default="GlowStrength")
    call.pin("ParameterValue", 'PinCategory="real",PinSubCategory="float"', default=strength)
    component = graph.get(f"{name}_Mesh", MESH, object_type("StaticMeshComponent"), x, y + 205)
    graph.link(component, MESH, call, "self")
    return call


def add_burn_cycle(graph):
    graph.note("ActivationGroup", "Activation · turn on the held ChemLight once", -50, -110, 1770, 520)
    graph.note("ExpiryGroup", "Expiry · turn off the light and unlock disposal", 1780, -110, 1120, 520)
    activate = graph.event("ActivateChemLight", 0, 0)
    activated = graph.get("ReadActivation", STARTED, "bool", 280, 225)
    guard = graph.branch("FirstActivationOnly", 280, 0)
    mark = graph.set_flag("MarkActivated", STARTED, "true", 540, 0)
    turn_on = set_light_visibility(graph, "EnableBlueLight", "true", 840, 0)
    start_glow = set_tube_emission(graph, "EnableTubeGlow", BLUE_EMISSION, 1140, 0)
    duration = graph.function("BurnDuration", "KismetSystemLibrary", "Delay", 1510, 0)
    duration.pin("Duration", 'PinCategory="real",PinSubCategory="float"', default=BURN_TIME)
    turn_off = set_light_visibility(graph, "DisableBlueLight", "false", 1840, 0)
    end_glow = set_tube_emission(graph, "DisableTubeGlow", "0.0", 2140, 0)
    ready = graph.set_flag("MarkReadyToThrow", DISPOSABLE, "true", 2520, 0)
    graph.chain(activate, guard)
    graph.link(activated, STARTED, guard, "Condition")
    graph.link(guard, "else", mark, "execute")
    graph.chain(mark, turn_on, start_glow, duration, turn_off, end_glow, ready)


def add_spent_throw(graph):
    graph.note("DisposalGroup", "Disposal · detach and throw only after the light is spent", -50, 500, 2350, 590)
    velocity_pin = "ThrowVelocityCmPerSecond"
    throw = graph.event("TryThrowSpentChemLight", 0, 610, vector_input=velocity_pin)
    allowed = graph.get("ReadThrowAvailability", DISPOSABLE, "bool", 340, 960)
    guard = graph.branch("ThrowOnlyWhenSpent", 340, 610)
    mark = graph.set_flag("ConsumeThrowAvailability", DISPOSABLE, "false", 620, 610)

    detach = graph.function("DetachFromHand", "Actor", "K2_DetachFromActor", 930, 610, owner_pin=False)
    rule = 'PinCategory="byte",PinSubCategoryObject="/Script/CoreUObject.Enum\'/Script/Engine.EDetachmentRule\'"'
    for name in ("LocationRule", "RotationRule", "ScaleRule"):
        detach.pin(name, rule, default="KeepWorld")

    collision = graph.function("UseWorldCollision", "PrimitiveComponent", "SetCollisionProfileName", 1240, 610)
    collision.pin("InCollisionProfileName", "name", default="PhysicsActor")
    collision.pin("bUpdateOverlaps", "bool", default="true")
    physics = graph.function("EnableRigidBody", "PrimitiveComponent", "SetSimulatePhysics", 1580, 610)
    physics.pin("bSimulate", "bool", default="true")
    launch = graph.function("LaunchSpentStick", "PrimitiveComponent", "SetPhysicsLinearVelocity", 1890, 610)
    launch.pin("NewVel", VECTOR)
    launch.pin("bAddToCurrent", "bool", default="false")
    launch.pin("BoneName", "name", default="None")

    for call, x in ((collision, 1240), (physics, 1580), (launch, 1890)):
        component = graph.get(f"{call.name}_Mesh", MESH, object_type("StaticMeshComponent"), x, 950)
        graph.link(component, MESH, call, "self")
    graph.chain(throw, guard, mark, detach, collision, physics, launch)
    graph.link(allowed, DISPOSABLE, guard, "Condition")
    graph.link(throw, velocity_pin, launch, "NewVel")


def main():
    graph = Graph()
    add_burn_cycle(graph)
    add_spent_throw(graph)
    for node in graph.nodes:
        for pin in node.pins.values():
            assert all(pin in other.links for other in pin.links)
    OUTPUT.write_text("\n".join(node.render() for node in graph.nodes) + "\n", encoding="utf-8")
    print(f"Wrote {len(graph.nodes)} Blueprint nodes and comment boxes")


if __name__ == "__main__":
    main()
