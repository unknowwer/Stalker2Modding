"""Verify the exported ChemLight's shape, rig and rigid weighting."""

import json
from pathlib import Path
import sys

import bpy


source, report = map(Path, sys.argv[sys.argv.index("--") + 1:])
bpy.ops.object.select_all(action="SELECT")
bpy.ops.object.delete(use_global=False)
bpy.ops.import_scene.fbx(filepath=str(source))
mesh, = (obj for obj in bpy.context.scene.objects if obj.type == "MESH")
rig, = (obj for obj in bpy.context.scene.objects if obj.type == "ARMATURE")
expected_bones = json.loads(report.read_text(encoding="utf-8"))["gilka"]["bones"]
assert len(rig.data.bones) == len(expected_bones)
for reference in expected_bones:
    bone = rig.data.bones[reference["name"]]
    assert (bone.parent.name if bone.parent else "None") == reference["parent"]

points = [mesh.matrix_world @ vertex.co for vertex in mesh.data.vertices]
dimensions = [max(p[axis] for p in points) - min(p[axis] for p in points) for axis in range(3)]
assert abs(dimensions[2] - 0.18) < 0.001, dimensions
assert len(mesh.data.polygons) == 2612
assert len(mesh.material_slots) == 2
weight_index = mesh.vertex_groups["jnt_offset"].index
for vertex in mesh.data.vertices:
    assert [group.group for group in vertex.groups] == [weight_index]
    assert abs(vertex.groups[0].weight - 1.0) < 0.0001
print(f"Verified 12 bones, 2 materials, rigid skin and dimensions of {dimensions} meters")
