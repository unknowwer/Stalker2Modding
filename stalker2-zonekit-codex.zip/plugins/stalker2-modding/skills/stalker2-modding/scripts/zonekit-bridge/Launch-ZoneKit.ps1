param(
    [string]$ZoneKitDirectory = $(if ($env:STALKER2_ZONE_KIT) {
        $env:STALKER2_ZONE_KIT
    } else {
        Join-Path $env:ProgramFiles 'STALKER2ZoneKit'
    })
)

$ErrorActionPreference = 'Stop'
$project = Join-Path $ZoneKitDirectory 'Stalker2\Stalker2.uproject'
$editor = Join-Path $ZoneKitDirectory 'Stalker2\Binaries\Win64\Stalker2ModEditor-Win64-Shipping.exe'
$startup = Join-Path $PSScriptRoot 'Startup'

foreach ($file in @($project, $editor, (Join-Path $startup 'init_unreal.py'))) {
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        throw "Required Zone Kit file was not found: $file"
    }
}

$previousPythonPath = $env:UE_PYTHONPATH
try {
    $env:UE_PYTHONPATH = $(if ($previousPythonPath) {
        "$startup;$previousPythonPath"
    } else {
        $startup
    })
    Start-Process -FilePath $editor -ArgumentList ('"{0}"' -f $project) -WindowStyle Normal
} finally {
    $env:UE_PYTHONPATH = $previousPythonPath
}
