"""Report the Zone Kit classifier and Windows staging output without changing files."""

import argparse
from datetime import datetime
import json
from pathlib import Path
import re


def classification(path):
    if not path.is_file():
        return set()
    return {line.strip().replace("\\", "/").casefold()
            for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()}


def file_info(path):
    stat = path.stat()
    return {"path": str(path), "size": stat.st_size,
            "modified": datetime.fromtimestamp(stat.st_mtime).astimezone().isoformat()}


def inspect(root, mod):
    project = root / "Stalker2"
    plugin = project / "Mods" / mod
    if not (plugin / f"{mod}.uplugin").is_file():
        raise ValueError(f"Missing mod descriptor in {plugin}")
    saved = project / "SavedMods"
    classifiers = saved / "PackageClassifier" / mod
    new_list = classifiers / "NewPackages.txt"
    override_list = classifiers / "OverridePackages.txt"
    new = classification(new_list)
    overrides = classification(override_list)
    staged = saved / "Staged" / mod / "Windows"
    content = [path for path in (plugin / "Content").rglob("*")
               if path.is_file() and path.suffix.casefold() in {".uasset", ".umap", ".cfg"}]
    newest = max(content, key=lambda path: path.stat().st_mtime, default=None)
    containers = {}
    for kind in ("NewContent", "OverrideContent"):
        folder = staged / kind / "Windows" / "Stalker2" / "Mods" / mod / "Content" / "Paks" / "Windows"
        stem = f"{mod}Stalker2-Windows-{kind}"
        files = [folder / f"{stem}.{extension}" for extension in ("pak", "utoc", "ucas")]
        present = [path for path in files if path.is_file() and path.stat().st_size]
        newest_container = max((path.stat().st_mtime for path in present), default=0)
        containers[kind] = {
            "files": [file_info(path) for path in present],
            "missing": [path.name for path in files if path not in present],
            "source_newer": newest.stat().st_mtime > newest_container if present and newest else None,
        }
    return {"mod": mod, "classifier_overlap": sorted(new & overrides),
            "classifier_missing": [path.name for path in (new_list, override_list) if not path.is_file()],
            "new_packages": len(new), "override_packages": len(overrides),
            "newest_source": file_info(newest) if newest else None, "staged": containers}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zone-kit", type=Path, required=True)
    parser.add_argument("--mod", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_]+", args.mod):
        parser.error("Expected a mod name without path separators")
    try:
        report = inspect(args.zone_kit.resolve(strict=True), args.mod)
    except (OSError, ValueError) as error:
        parser.exit(1, f"{error}\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
