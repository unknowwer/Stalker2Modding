"""Expose Zone Kit editor tools through MCP over stdio."""

import json
import sys

from zonekit_bridge import BridgeError, TOOLS, call


PROTOCOLS = {"2024-11-05", "2025-03-26", "2025-06-18", "2025-11-25"}
LATEST = "2025-11-25"


class RequestError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def tool_result(value, failed=False):
    return {
        "content": [{"type": "text", "text": json.dumps(value, ensure_ascii=False)}],
        "isError": failed,
    }


def dispatch(method, params):
    if not isinstance(params, dict):
        raise RequestError(-32602, "Expected params object")
    if method == "initialize":
        requested = params.get("protocolVersion")
        return {
            "protocolVersion": requested if isinstance(requested, str) and requested in PROTOCOLS else LATEST,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "flares-zonekit", "version": "3.0.0"},
            "instructions": "Start this version of zonekit_bridge.py in Zone Kit. Use zonekit_status, zonekit_list_mounts and zonekit_graph_capabilities to discover the live editor.",
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return {"tools": [tool.mcp_schema() for tool in TOOLS.values()]}
    if method == "tools/call":
        name = params.get("name")
        prefix = "zonekit_"
        if not isinstance(name, str) or not name.startswith(prefix) or name[len(prefix):] not in TOOLS:
            raise RequestError(-32602, "Unknown tool")
        try:
            return tool_result(call(name[len(prefix):], params.get("arguments", {})))
        except (BridgeError, OSError, ValueError) as error:
            return tool_result({"error": str(error)}, failed=True)
    raise RequestError(-32601, "Method not found")


def error_response(request_id, code, message):
    return {"jsonrpc": "2.0", "id": request_id, "error": {"code": code, "message": message}}


def handle(line):
    try:
        request = json.loads(line.decode("utf-8"))
    except (ValueError, UnicodeError):
        return error_response(None, -32700, "Invalid JSON")
    if not isinstance(request, dict) or request.get("jsonrpc") != "2.0" or not isinstance(request.get("method"), str):
        return error_response(None, -32600, "Invalid request")
    if "id" not in request:
        return None
    request_id = request["id"]
    try:
        result = dispatch(request["method"], request.get("params", {}))
        return {"jsonrpc": "2.0", "id": request_id, "result": result}
    except RequestError as error:
        return error_response(request_id, error.code, str(error))


def main():
    for line in sys.stdin.buffer:
        if not line.strip():
            continue
        response = handle(line)
        if response is not None:
            sys.stdout.buffer.write((json.dumps(response, ensure_ascii=False) + "\n").encode("utf-8"))
            sys.stdout.buffer.flush()


if __name__ == "__main__":
    main()
