# Zone Kit MCP Bridge v3

Редакторне розширення для Zone Kit 5.5.4. MCP-сервер спілкується з Codex через stdio. Python-скрипт усередині Zone Kit читає запити з локального каталогу `exchange` і виконує їх на потоці редактора. Міст охоплює всі змонтовані каталоги Unreal, які відкриває поточна сесія.

## Запуск

1. У вже відкритому Zone Kit введи абсолютний шлях до `zonekit_bridge.py` у нижній консолі **Python**. У режимі **Cmd** використовуй `py "C:/шлях/до/FlaresBridge/zonekit_bridge.py"`.
2. Встанови плагін із локального джерела репозиторію або підключи сервер вручну за прикладом нижче. Перезапусти Codex, щоб він перечитав інструменти сервера `flares-zonekit`.
3. Виклич `zonekit_status`, `zonekit_list_mounts` і `zonekit_graph_capabilities`.

Для автоматичного запуску моста відкрий редактор вручну через `Launch-ZoneKit.ps1`. Параметр `-ZoneKitDirectory` задає інший каталог встановлення. Скрипт передає новому процесу `UE_PYTHONPATH`, через який підхоплюється `Startup/init_unreal.py`. [Epic Unreal Python 5.5](https://dev.epicgames.com/documentation/en-us/unreal-engine/scripting-the-unreal-editor-using-python?application_version=5.5)

MCP-сервер і редакторний скрипт використовують спільну папку даних `%LOCALAPPDATA%/Stalker2ZoneKitCodex`. Для іншої папки задай однакову змінну `ZONEKIT_MCP_HOME` в обох процесах. Міст читає `bridge_settings.json` з цієї папки. Щоб увімкнути редагування, скопіюй туди `bridge_settings.example.json` як `bridge_settings.json`, зміни `allow_writes` на `true` і перезапусти скрипт у Zone Kit.

```toml
[mcp_servers.flares-zonekit]
command = "C:/Program Files/STALKER2ZoneKit/Engine/Binaries/ThirdParty/Python3/Win64/python.exe"
args = ["-B", "C:/absolute/path/FlaresBridge/zonekit_mcp.py"]
```

## Операції

| MCP | Призначення |
| --- | --- |
| `zonekit_status`, `zonekit_list_mounts`, `zonekit_list_assets`, `zonekit_get_asset` | Перевірка сесії та пошук по грі й підключених модах |
| `zonekit_inspect_blueprint`, `zonekit_graph_capabilities` | Клас, компоненти, Event Graph і доступні редакторні API |
| `zonekit_create_blueprint`, `zonekit_add_blueprint_function`, `zonekit_add_blueprint_variable` | Створення Blueprint і редагування його структури |
| `zonekit_get_blueprint_default`, `zonekit_set_blueprint_default` | Читання і редагування простих значень за замовчуванням |
| `zonekit_set_point_light` | Зміна яскравості, дальності, форми джерела й тіней Point Light |
| `zonekit_compile_blueprint`, `zonekit_save_asset` | Окремий виклик компіляції та збереження |
| `zonekit_inspect_graph`, `zonekit_export_blueprint_t3d` | Читання об’єктів Event Graph і посторінковий експорт Blueprint у штатному форматі Unreal |
| `zonekit_add_function_call`, `zonekit_ensure_event_override`, `zonekit_set_pin_default` | Типізоване редагування через C++-адаптер |
| `zonekit_import_graph_nodes`, `zonekit_connect_graph_pins` | Імпорт T3D та прямі з’єднання через C++-адаптер |

`zonekit_create_blueprint` приймає шлях пакета, наприклад `/MyMod/Blueprints/BP_Light`, і шлях класу, наприклад `/Script/Engine.Actor`. `zonekit_set_blueprint_default` приймає скалярне поле `value`. Запис потребує `allow_writes` у локальних налаштуваннях. Під час PIE доступне читання. Для штатних асетів Zone Kit може вимагати Checkout у мод. Збереження вміщує і попередні незбережені правки цільового асета. Якщо `compiler_status` порожній, API повідомив лише, що компілятор викликано. [Unreal BlueprintEditorLibrary 5.5](https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/BlueprintEditorLibrary?application_version=5.5)

## Вузли й піни

У базовому Zone Kit 5.5.4 немає підтвердженого Python API для імпорту K2-вузлів і з’єднання пінів. Вихідний код адаптера лежить у `Native/ZoneKitGraphAdapter`. Для нього потрібні сумісні вихідні файли й ціль редактора від збірки Zone Kit. Встановлений пакет не містить необхідних заголовків. Готовий двійковий файл і перевірка завантаження в цій збірці поки відсутні.

У живій сесії Zone Kit через MCP перевірено створення тестового Blueprint, читання вузлів Event Graph і T3D-експорт із піном `then` події `ReceiveBeginPlay`. Команда компіляції викликана, статус недоступний через Python API. `RunUAT BuildPlugin` у цьому комплекті повернув `Failed to find command BuildPlugin`. Тестові зміни залишилися в пам’яті редактора.

Після завантаження сумісного адаптера перевір `zonekit_graph_capabilities`. Нативна інспекція повертає GUID, напрямок, тип, значення й з’єднання пінів. Команди редагування використовують GUID та імена пінів. Схема K2 перевіряє значення та прямі з’єднання перед записом. Компілятор повертає статус і діагностику окремо від збереження. [Unreal Graph Import 5.5](https://dev.epicgames.com/documentation/unreal-engine/API/Editor/UnrealEd/FEdGraphUtilities/ImportNodesFromText?application_version=5.5)

`test_graph_mcp.py` виконує перевірку через сервер MCP на `/Flares/EditorTests/BP_ZoneKitGraphSmoke`. З адаптером він створює зв’язку `BeginPlay → Print String`, задає текст на вході, компілює й перевіряє обидва кінці з’єднання. Прапорець `--save` зберігає тестовий Blueprint лише після повної перевірки. Код завершення 2 означає, що повна перевірка заблокована можливостями редактора або компіляцією. Тестовий асет призначений для редактора.

Модель окремих команд створення вузлів і читання зв’язків звірено з PinWright. Захоплення діагностики компілятора та пошук реальних функцій звірено з MCP Toolkit. Обидва проєкти використовувалися як технічні довідки. [PinWright](https://github.com/PinWright/pinwright-ue) · [Unreal Engine MCP Toolkit](https://github.com/eliestroun14/unreal-engine-mcp-toolkit)

## Перевірка збірки мода

`inspect_mod_build.py --zone-kit "C:/Program Files/STALKER2ZoneKit" --mod Flares` читає класифікатор пакетів, перевіряє наявність файлів `.pak`, `.utoc`, `.ucas` та порівнює час збірки з файлами мода. Пізніша зміна джерела позначає збірку для повторної перевірки. Див. [огляд Modding Harness](Modding-Harness-review.md).

Власні інструменти додавай до `TOOLS` у `zonekit_tools.py`. Реєстрація містить схему аргументів і Python-функцію, яка працює з `worker.unreal`. Після зміни реєстру перезапусти обидва кінці моста. MCP приймає лише зареєстровані операції з редактором.

Зберігай міст у локальній папці свого облікового запису. Якщо запис завершився тайм-аутом, перечитай стан асета перед повтором, оскільки редактор міг виконати операцію до втрати відповіді.
