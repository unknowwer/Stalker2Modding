# Огляд S.T.A.L.K.E.R. 2 Modding Harness

Статична перевірка доступних скриптів для налаштування, роботи з редактором, пакування, встановлення та випуску. Harness не встановлювався й не запускався. У мосту використано власну реалізацію. Перевірка охоплює вказані файли, а не всю історію й усі залежності репозиторію.

## Як працює

- Редакторні скрипти запускаються через Unreal Python Remote Execution або через окремий командний запуск Zone Kit. Графи читаються через T3D. Генератор готує текст вузлів із двосторонніми зв’язками, а вставлення відбувається в Blueprint Editor. [Перелік інструментів](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/README.md) · [Робота з Blueprint](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/docs/blueprints.md)
- Пакування викликає `GSCCookMod` із шляхами до мода й класифікатора. Стадії NewContent і OverrideContent обробляються окремо. Інсталятор зберігає штатну назву NewContent, додає пріоритет до OverrideContent і шукає другий встановлений NewContent перед тестом. [Пакування](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/tools/cook_and_install.ps1) · [Тестове встановлення](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/tools/install_paktest.ps1)
- Випуск збирає ZIP з останнього cook. Стан редактора й копія мода в репозиторії синхронізуються окремими командами. [Випуск](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/tools/make_release.py) · [Розгортання](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/tools/deploy_to_kit.ps1)

## Результат перевірки безпеки

| Код | Знайдена поведінка | Рішення для нашого аддона |
| --- | --- | --- |
| `setup.ps1`, `ue_exec.py` | Налаштування може увімкнути Remote Execution у `DefaultEngine.ini`. Клієнт обирає перший знайдений редактор і передає довільний Python для виконання. | Локальний файловий MCP з реєстром конкретних операцій та ідентифікатором сесії. |
| `setup.ps1` | За прапорцями встановлює Git і GitHub CLI, робить fork і змінює Git remote. Записує машинні налаштування. | Власний аддон працює з установленим Zone Kit і не потребує GitHub чи інсталятора. |
| `common.ps1`, `deploy_to_kit.ps1`, `install_paktest.ps1` | Дзеркальне копіювання видаляє зайві файли в каталозі призначення. Інсталятор очищає тестовий каталог wildcard-ом перед копіюванням. Назва мода з аргументу передається до шляхів без перевірки формату в `Get-ModName`. | Перший інструмент лише читає. Для майбутнього запису потрібні перевірені абсолютні корені та перелік конкретних файлів у маніфесті. |
| `cook_and_install.ps1` | Cook, копіювання класифікатора і встановлення йдуть в одному процесі за замовчуванням. | Окремі операції cook, перевірки та встановлення з окремими результатами. |

[Налаштування](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/tools/setup.ps1) · [Віддалене виконання](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/tools/ue_exec.py) · [Спільні функції](https://raw.githubusercontent.com/noahsemus/stalker2-modding-harness/main/harness/tools/common.ps1)

Перший власний крок реалізовано в `inspect_mod_build.py`. Він виявляє перетин класифікаторів, неповні контейнери та новіші вихідні файли без запису в Zone Kit або гру.
