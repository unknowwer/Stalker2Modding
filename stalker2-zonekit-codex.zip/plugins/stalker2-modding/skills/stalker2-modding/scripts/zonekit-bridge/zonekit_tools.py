"""Local tool registry shared by the MCP server and the Zone Kit worker."""

from dataclasses import dataclass
import math
from pathlib import Path
import re
from tempfile import TemporaryDirectory


DEFAULT_PATH = "/Flares/ChemLight"
CHEMLIGHT_HELD_MESH = f"{DEFAULT_PATH}/SK_ChemLight_Gilka"
CHEMLIGHT_MOUNT = "jnt_offset"
CHEMLIGHT_PROTOTYPES = (
    (f"{DEFAULT_PATH}/SK_ChemLight", "SkeletalMesh"),
    (f"{DEFAULT_PATH}/SK_ChemLight_Skeleton", "Skeleton"),
)
MAX_ASSETS = 200
NAME = r"[A-Za-z0-9_]+"
SEGMENT = r"[\w-]+"
FOLDER = rf"/(?:{SEGMENT}(?:/{SEGMENT})*)?"
PACKAGE = rf"/{SEGMENT}(?:/{SEGMENT})+"
ASSET = rf"{PACKAGE}(?:\.{SEGMENT})?"
CLASS = rf"{PACKAGE}\.{SEGMENT}"
VARIABLE_TYPES = ("bool", "byte", "int", "name", "real", "string", "text")
POINT_LIGHT_PROPERTIES = {
    "intensity": "intensity",
    "radius_cm": "attenuation_radius",
    "source_radius_cm": "source_radius",
    "soft_source_radius_cm": "soft_source_radius",
    "source_length_cm": "source_length",
    "cast_shadows": "cast_shadows",
    "specular_scale": "specular_scale",
}
POINT_LIGHT_PARAMETERS = {
    "intensity": {"type": "number", "minimum": 0, "maximum": 100000},
    "radius_cm": {"type": "number", "minimum": 1, "maximum": 100000},
    "source_radius_cm": {"type": "number", "minimum": 0, "maximum": 100000},
    "soft_source_radius_cm": {"type": "number", "minimum": 0, "maximum": 100000},
    "source_length_cm": {"type": "number", "minimum": 0, "maximum": 100000},
    "cast_shadows": {"type": "boolean"},
    "specular_scale": {"type": "number", "minimum": 0, "maximum": 1},
}


class BridgeError(Exception):
    pass


def arguments(properties=None, *, required=(), **rules):
    return {
        "type": "object",
        "properties": properties or {},
        "required": list(required),
        "additionalProperties": False,
        **rules,
    }


def string(pattern):
    return {"type": "string", "pattern": f"^{pattern}$", "maxLength": 256}


def text(max_length):
    return {"type": "string", "minLength": 1, "maxLength": max_length}


ASSET_ARGUMENT = {"asset": string(ASSET)}
ASSET_SCHEMA = arguments(ASSET_ARGUMENT, required=("asset",))
GRAPH_ARGUMENTS = {**ASSET_ARGUMENT, "graph": string(NAME)}
NODE_GUID = string("[A-Fa-f0-9]{32}")
GRAPH_COORDINATE = {"type": "integer", "minimum": -100000, "maximum": 100000}


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    schema: dict
    action: object
    read_only: bool = True
    destructive: bool = False

    def mcp_schema(self):
        return {
            "name": f"zonekit_{self.name}",
            "description": self.description,
            "inputSchema": self.schema,
            "annotations": {
                "readOnlyHint": self.read_only,
                "destructiveHint": self.destructive,
                "openWorldHint": False,
            },
        }


def validate(operation, values):
    tool = TOOLS.get(operation) if isinstance(operation, str) else None
    if tool is None or not isinstance(values, dict):
        raise BridgeError("Unsupported operation or arguments")
    properties = tool.schema["properties"]
    if values.keys() - properties.keys() or set(tool.schema["required"]) - values.keys():
        raise BridgeError("Unexpected or missing tool arguments")
    result = {}
    for name, field in properties.items():
        if name not in values:
            if "default" in field:
                result[name] = field["default"]
            continue
        value = values[name]
        kind = field["type"]
        if kind == "string":
            pattern = field.get("pattern")
            valid = (
                isinstance(value, str) and field.get("minLength", 0) <= len(value) <= field["maxLength"]
                and (pattern is None or re.fullmatch(pattern, value) is not None)
                and ("enum" not in field or value in field["enum"])
            )
        elif kind == "boolean":
            valid = type(value) is bool
        elif kind == "number":
            valid = (type(value) in (int, float)
                     and field["minimum"] <= value <= field["maximum"] and math.isfinite(value))
        elif kind == "integer":
            valid = type(value) is int and field["minimum"] <= value <= field["maximum"]
        elif kind == ["boolean", "number", "string"]:
            valid = type(value) in (bool, int, float, str)
        else:
            raise BridgeError(f"Unsupported schema type {kind}")
        if not valid:
            raise BridgeError(f"Invalid {name}")
        result[name] = value
    if operation == "set_point_light" and not (POINT_LIGHT_PROPERTIES.keys() & result.keys()):
        raise BridgeError("Specify at least one Point Light setting")
    if "asset" in result:
        package, period, name = result["asset"].partition(".")
        if period and name != package.rsplit("/", 1)[-1]:
            raise BridgeError("Use an asset package or its top-level object path")
    return result


def list_assets(worker, path, recursive):
    if path == "/":
        return list_mounts(worker)
    assets = worker.unreal.EditorAssetLibrary
    exists = assets.does_directory_exist(path)
    paths = assets.list_assets(path, recursive=recursive, include_folder=False) if exists else []
    entries = sorted(map(str, paths))
    return {"path": path, "exists": exists, "count": len(entries),
            "assets": entries[:MAX_ASSETS], "truncated": len(entries) > MAX_ASSETS}


def load_asset(unreal, path):
    asset = unreal.EditorAssetLibrary.load_asset(path)
    if asset is None:
        raise BridgeError(f"Asset does not exist: {path}")
    return asset


def load_blueprint(unreal, path):
    blueprint = load_asset(unreal, path)
    if not isinstance(blueprint, unreal.Blueprint):
        raise BridgeError(f"Expected a Blueprint: {path}")
    return blueprint


def registry(unreal):
    return unreal.AssetRegistryHelpers.get_asset_registry()


def list_mounts(worker):
    paths = registry(worker.unreal).get_sub_paths("/", False)
    return {"mounts": sorted(set(map(str, paths or [])))}


def get_asset(worker, asset):
    obj = load_asset(worker.unreal, asset)
    return {"asset": obj.get_path_name(), "class": obj.get_class().get_path_name()}


def asset_references(worker, asset):
    unreal = worker.unreal
    package = asset.split(".", 1)[0]
    index = registry(unreal)
    options = unreal.AssetRegistryDependencyOptions(
        include_hard_package_references=True, include_soft_package_references=True,
    )
    return {"asset": package,
            "dependencies": sorted(map(str, index.get_dependencies(package, options) or []))[:MAX_ASSETS],
            "referencers": sorted(map(str, index.get_referencers(package, options) or []))[:MAX_ASSETS]}


def remove_flares_prototypes(worker):
    unreal = worker.unreal
    assets = unreal.EditorAssetLibrary
    index = registry(unreal)
    if index.is_loading_assets():
        raise BridgeError("Wait for the asset registry to finish loading")
    if not isinstance(load_asset(unreal, CHEMLIGHT_HELD_MESH), unreal.SkeletalMesh):
        raise BridgeError("The active held mesh is missing or has an unexpected class")

    target_paths = {path for path, _ in CHEMLIGHT_PROTOTYPES}
    dirty = {package.get_path_name() for package in unreal.EditorLoadingAndSavingUtils.get_dirty_content_packages()}
    pending = []
    for path, class_name in CHEMLIGHT_PROTOTYPES:
        if not assets.does_asset_exist(path):
            continue
        obj = load_asset(unreal, path)
        if obj.get_path_name() != f"{path}.{path.rsplit('/', 1)[-1]}" or obj.get_class().get_name() != class_name:
            raise BridgeError(f"Unexpected asset at {path}")
        if path in dirty:
            raise BridgeError(f"The prototype has unsaved changes: {path}")
        refs = set(map(str, assets.find_package_referencers_for_asset(path, load_assets_to_confirm=True)))
        if refs - target_paths:
            raise BridgeError(f"{path} is still referenced by {', '.join(sorted(refs - target_paths))}")
        pending.append(obj)

    if pending:
        assets.delete_loaded_assets(pending)
    remaining = [path for path, _ in CHEMLIGHT_PROTOTYPES if assets.does_asset_exist(path)]
    return {"remaining": remaining,
            "removed_or_already_absent": sorted(target_paths - set(remaining)),
            "held_mesh_exists": assets.does_asset_exist(CHEMLIGHT_HELD_MESH)}


def add_to_local_collection(worker, asset, name):
    unreal = worker.unreal
    obj = load_asset(unreal, asset)
    tags = unreal.get_engine_subsystem(unreal.AssetTagsSubsystem)
    if not tags.collection_exists(name):
        if not tags.create_collection(name, unreal.CollectionShareType.LOCAL):
            raise BridgeError(f"Could not create local collection {name}")
    if name not in map(str, tags.get_collections_containing_asset_ptr(obj)):
        if not tags.add_assets_to_collection(name, [obj.get_path_name()]):
            raise BridgeError(f"Could not add {asset} to {name}")
    return {"name": name, "assets": sorted(str(item.package_name) for item in tags.get_assets_in_collection(name))}


def vector_values(vector):
    return [round(float(vector.x), 4), round(float(vector.y), 4), round(float(vector.z), 4)]


def held_mesh_preview(unreal):
    mesh = load_asset(unreal, CHEMLIGHT_HELD_MESH)
    if not isinstance(mesh, unreal.SkeletalMesh):
        raise BridgeError("The held ChemLight is missing its skeletal mesh")
    component = unreal.new_object(unreal.SkeletalMeshComponent)
    component.set_skinned_asset_and_update(mesh)
    if component.get_bone_index(CHEMLIGHT_MOUNT) < 0:
        raise BridgeError("The held ChemLight is missing its detector grip bone")
    return mesh, component


def inspect_chemlight_emitter(worker):
    mesh, component = held_mesh_preview(worker.unreal)
    bounds = mesh.get_imported_bounds()
    socket = mesh.find_socket(CHEMLIGHT_MOUNT)
    return {"mesh": mesh.get_path_name(), "bounds_center_cm": vector_values(bounds.origin),
            "bounds_half_size_cm": vector_values(bounds.box_extent),
            "attachment_cm": vector_values(component.get_socket_location(CHEMLIGHT_MOUNT)),
            "socket": socket.get_path_name() if socket else None,
            "socket_parent": str(socket.bone_name) if socket else None,
            "relative_location_cm": vector_values(socket.relative_location) if socket else None,
            "add_socket_available": hasattr(mesh, "add_socket")}


def create_blueprint(worker, asset, parent_class):
    unreal = worker.unreal
    if unreal.EditorAssetLibrary.does_asset_exist(asset):
        raise BridgeError(f"An asset already exists at {asset}")
    parent = unreal.load_class(None, parent_class)
    if parent is None:
        raise BridgeError(f"Could not resolve parent class {parent_class}")
    blueprint = unreal.BlueprintEditorLibrary.create_blueprint_asset_with_parent(asset, parent)
    if blueprint is None:
        raise BridgeError(f"Zone Kit could not create a Blueprint at {asset}")
    return {"asset": blueprint.get_path_name(), "parent_class": parent_class, "saved": False}


def add_blueprint_function(worker, asset, name):
    unreal = worker.unreal
    blueprint = load_blueprint(unreal, asset)
    library = unreal.BlueprintEditorLibrary
    if library.find_graph(blueprint, name):
        raise BridgeError(f"A graph named {name} already exists")
    graph = library.add_function_graph(blueprint, name)
    if graph is None or graph.get_name() != name:
        raise BridgeError(f"Zone Kit could not create function graph {name}")
    return {"asset": blueprint.get_path_name(), "graph": graph.get_name(), "saved": False}


def add_blueprint_variable(worker, asset, name, variable_type):
    unreal = worker.unreal
    blueprint = load_blueprint(unreal, asset)
    library = unreal.BlueprintEditorLibrary
    pin_type = library.get_basic_type_by_name(variable_type)
    if not library.add_member_variable(blueprint, name, pin_type):
        raise BridgeError(f"Zone Kit could not add variable {name}")
    return {"asset": blueprint.get_path_name(), "variable": name,
            "variable_type": variable_type, "saved": False}


def blueprint_default(worker, asset, property_name, value=None):
    unreal = worker.unreal
    blueprint = load_blueprint(unreal, asset)
    generated_class = blueprint.generated_class()
    if not generated_class:
        raise BridgeError("Compile the Blueprint before accessing its class defaults")
    defaults = unreal.get_default_object(generated_class)
    before = defaults.get_editor_property(property_name)
    if type(before) not in (bool, int, float, str):
        raise BridgeError("Use a locally authored feature for this non-scalar property")
    result = {"asset": blueprint.get_path_name(), "property": property_name, "value": before}
    if value is None:
        return result
    replacement = value
    if type(before) is float and type(replacement) in (int, float):
        if not (-1e308 <= replacement <= 1e308):
            raise BridgeError("Expected a finite numeric value")
        replacement = float(replacement)
    if type(replacement) is not type(before):
        raise BridgeError(f"Expected a {type(before).__name__} value")
    with unreal.ScopedEditorTransaction("Zone Kit MCP: edit Blueprint default"):
        blueprint.modify()
        defaults.modify()
        defaults.set_editor_property(property_name, replacement)
    return {**result, "previous_value": before, "value": defaults.get_editor_property(property_name),
            "saved": False}


def graph_backend(worker):
    return getattr(worker.unreal, "ZoneKitGraphLibrary", None)


def graph_capabilities(worker):
    library = worker.unreal.BlueprintEditorLibrary
    backend = graph_backend(worker)
    return {
        "create_blueprint": callable(getattr(library, "create_blueprint_asset_with_parent", None)),
        "add_function_graph": callable(getattr(library, "add_function_graph", None)),
        "add_member_variable": callable(getattr(library, "add_member_variable", None)),
        "import_nodes": callable(getattr(backend, "import_nodes", None)),
        "inspect_nodes": callable(getattr(backend, "describe_nodes", None)),
        "inspect_event_node_objects": bool(getattr(worker.unreal, "ObjectIterator", None)
                                           and getattr(worker.unreal, "EdGraphNode", None)),
        "export_blueprint_t3d": callable(getattr(worker.unreal, "ObjectExporterT3D", None)),
        "connect_pins": callable(getattr(backend, "connect_pins", None)),
        "add_function_call": callable(getattr(backend, "add_function_call", None)),
        "ensure_event_override": callable(getattr(backend, "ensure_event_override", None)),
        "set_pin_default": callable(getattr(backend, "set_pin_default", None)),
        "compile_diagnostics": callable(getattr(backend, "compile_with_diagnostics", None)),
    }


def graph_node_details(result):
    return [
        {
            "guid": str(node.guid),
            "class": str(node.class_name),
            "member": str(node.member_name),
            "pins": [
                {"name": str(pin.name), "direction": str(pin.direction), "category": str(pin.category),
                 "default": str(pin.default_value), "links": list(map(str, pin.links))}
                for pin in node.pins
            ],
        }
        for node in getattr(result, "graph_nodes", ())
    ]


def call_graph_backend(worker, method, asset, graph, *args):
    unreal = worker.unreal
    implementation = getattr(graph_backend(worker), method, None)
    if not callable(implementation):
        raise BridgeError(f"This Zone Kit session has no native graph adapter for {method}")
    blueprint = load_blueprint(unreal, asset)
    result = implementation(blueprint, graph, *args)
    if not result.get_editor_property("success"):
        raise BridgeError(str(result.get_editor_property("message")))
    return {
        "asset": blueprint.get_path_name(),
        "graph": graph,
        "message": str(result.get_editor_property("message")),
        "nodes": list(map(str, result.get_editor_property("nodes"))),
        "graph_nodes": graph_node_details(result),
    }


def inspect_graph(worker, asset, graph):
    if graph_capabilities(worker)["inspect_nodes"]:
        return {**call_graph_backend(worker, "describe_nodes", asset, graph), "pins_available": True}
    unreal = worker.unreal
    if not graph_capabilities(worker)["inspect_event_node_objects"]:
        raise BridgeError("This Zone Kit session cannot inspect K2 node objects")
    blueprint = load_blueprint(unreal, asset)
    event_graph = unreal.BlueprintEditorLibrary.find_event_graph(blueprint)
    if event_graph is None or event_graph.get_name() != graph:
        raise BridgeError("Python inspection is available for the Blueprint event graph only")
    objects = [
        {"name": node.get_name(), "class": node.get_class().get_name()}
        for node in unreal.ObjectIterator(unreal.EdGraphNode) if node.get_outer() == event_graph
    ]
    return {"asset": blueprint.get_path_name(), "graph": graph, "pins_available": False,
            "graph_nodes": sorted(objects, key=lambda node: node["name"])}


def export_blueprint_t3d(worker, asset, offset):
    unreal = worker.unreal
    blueprint = load_blueprint(unreal, asset)
    exporter = getattr(unreal, "ObjectExporterT3D", None)
    if not callable(exporter):
        raise BridgeError("Zone Kit does not expose ObjectExporterT3D")
    with TemporaryDirectory(prefix="blueprint-export-", dir=worker.root) as folder:
        output = Path(folder) / "blueprint.t3d"
        task = unreal.AssetExportTask()
        task.object = blueprint
        task.exporter = exporter()
        task.filename = str(output)
        task.automated = True
        task.prompt = False
        if not unreal.Exporter.run_asset_export_task(task) or not output.is_file():
            raise BridgeError("T3D export failed: " + "; ".join(map(str, task.errors)))
        if output.stat().st_size > 8 * 1024 * 1024:
            raise BridgeError("T3D export exceeds 8 MiB")
        exported = output.read_bytes()
    encoding = "utf-16" if exported.startswith((b"\xff\xfe", b"\xfe\xff")) else "utf-8-sig"
    contents = exported.decode(encoding)
    limit = 24_000
    end = min(offset + limit, len(contents))
    return {"asset": blueprint.get_path_name(), "text": contents[offset:end],
            "next_offset": end if end < len(contents) else None, "total_characters": len(contents)}


def import_graph_nodes(worker, asset, graph, nodes_text):
    return {**call_graph_backend(worker, "import_nodes", asset, graph, nodes_text), "saved": False}


def connect_graph_pins(worker, asset, graph, output_node, output_pin, input_node, input_pin):
    result = call_graph_backend(worker, "connect_pins", asset, graph,
                                output_node, output_pin, input_node, input_pin)
    return {**result, "saved": False}


def add_function_call(worker, asset, graph, owner_class, function, x, y):
    result = call_graph_backend(worker, "add_function_call", asset, graph, owner_class, function, x, y)
    return {**result, "saved": False}


def ensure_event_override(worker, asset, graph, event, x, y):
    result = call_graph_backend(worker, "ensure_event_override", asset, graph, event, x, y)
    return {**result, "saved": False}


def set_pin_default(worker, asset, graph, node, pin, value):
    result = call_graph_backend(worker, "set_pin_default", asset, graph, node, pin, value)
    return {**result, "saved": False}


def own_components(unreal, blueprint):
    subsystem = unreal.get_engine_subsystem(unreal.SubobjectDataSubsystem)
    helper = unreal.SubobjectDataBlueprintFunctionLibrary
    prefix = f"{blueprint.get_path_name().split('.', 1)[0]}."
    components = {}
    for handle in subsystem.k2_gather_subobject_data_for_blueprint(blueprint):
        data = subsystem.k2_find_subobject_data_from_handle(handle)
        if data is None:
            continue
        component = helper.get_object_for_blueprint(data, blueprint)
        if isinstance(component, unreal.ActorComponent) and component.get_path_name().startswith(prefix):
            components[str(helper.get_variable_name(data))] = component
    return components


def light_values(light):
    return {
        **{name: light.get_editor_property(property_name)
           for name, property_name in POINT_LIGHT_PROPERTIES.items()},
        "intensity_units": str(light.get_editor_property("intensity_units")),
        "inverse_squared_falloff": light.get_editor_property("use_inverse_squared_falloff"),
        "absolute_location": light.get_editor_property("absolute_location"),
    }


def inspect_blueprint(worker, asset):
    unreal = worker.unreal
    blueprint = load_blueprint(unreal, asset)
    generated_class = blueprint.generated_class()
    components = [
        {"name": name, "class": obj.get_class().get_name(),
         **(light_values(obj) if isinstance(obj, unreal.PointLightComponent) else {})}
        for name, obj in sorted(own_components(unreal, blueprint).items())
    ]
    event_graph = unreal.BlueprintEditorLibrary.find_event_graph(blueprint)
    return {
        "asset": blueprint.get_path_name(),
        "generated_class": generated_class.get_path_name() if generated_class else None,
        "event_graph": event_graph.get_name() if event_graph else None,
        "components": components,
    }


def set_point_light(worker, asset, component, **settings):
    unreal = worker.unreal
    blueprint = load_blueprint(unreal, asset)
    light = own_components(unreal, blueprint).get(component)
    if not isinstance(light, unreal.PointLightComponent):
        raise BridgeError(f"No Point Light component owned by this Blueprint named {component}")
    before = light_values(light)
    changes = {name: value for name, value in settings.items() if value != before[name]}
    if changes:
        with unreal.ScopedEditorTransaction("Zone Kit MCP: edit Point Light") as transaction:
            blueprint.modify()
            light.modify()
            try:
                for name, value in changes.items():
                    light.set_editor_property(POINT_LIGHT_PROPERTIES[name], value)
            except Exception:
                for name in changes:
                    light.set_editor_property(POINT_LIGHT_PROPERTIES[name], before[name])
                transaction.cancel()
                raise
    return {"asset": blueprint.get_path_name(), "component": component,
            "before": before, "after": light_values(light), "saved": False}


def compile_blueprint(worker, asset):
    unreal = worker.unreal
    blueprint = load_blueprint(unreal, asset)
    compile_with_diagnostics = getattr(graph_backend(worker), "compile_with_diagnostics", None)
    if callable(compile_with_diagnostics):
        result = compile_with_diagnostics(blueprint)
        compiled = bool(result.get_editor_property("success"))
        return {"asset": blueprint.get_path_name(), "compile_invoked": True,
                "compiler_status": "success" if compiled else "error",
                "error_count": result.error_count, "warning_count": result.warning_count,
                "diagnostics": list(map(str, result.diagnostics)), "saved": False}
    unreal.BlueprintEditorLibrary.compile_blueprint(blueprint)
    try:
        status = str(blueprint.get_editor_property("status"))
    except Exception as error:
        # Some shipping editor builds do not reflect UBlueprint::Status.
        status = None
        unreal.log_warning(f"Zone Kit MCP could not read Blueprint status: {error}")
    return {"asset": blueprint.get_path_name(), "compile_invoked": True,
            "compiler_status": status, "saved": False}


def save_asset(worker, asset):
    unreal = worker.unreal
    obj = load_asset(unreal, asset)
    if not unreal.EditorAssetLibrary.save_loaded_asset(obj, only_if_is_dirty=False):
        raise BridgeError(f"Zone Kit did not save {asset}")
    return {"asset": obj.get_path_name(), "saved": True}


TOOLS = {tool.name: tool for tool in (
    Tool("status", "Check the live Zone Kit session and its edit mode.", arguments(), lambda worker: worker.status()),
    Tool("list_mounts", "List indexed content roots, including the base game and mounted mods.",
         arguments(), list_mounts),
    Tool("list_assets", "List asset paths in any indexed folder. Use / to list content roots.",
         arguments({"path": {**string(FOLDER), "default": DEFAULT_PATH},
                    "recursive": {"type": "boolean", "default": False}}), list_assets),
    Tool("get_asset", "Read the resolved path and Unreal class of any mounted asset.",
         ASSET_SCHEMA, get_asset),
    Tool("asset_references", "Read the hard and soft package references and referencers of an asset.",
         ASSET_SCHEMA, asset_references),
    Tool("remove_flares_prototypes", "Remove the two retired Flares skeletal assets after checking referencers and unsaved edits.",
         arguments(), remove_flares_prototypes, read_only=False, destructive=True),
    Tool("add_to_local_collection", "Add an asset to a named local Content Browser collection.",
         arguments({**ASSET_ARGUMENT, "name": text(64)}, required=("asset", "name")),
         add_to_local_collection, read_only=False),
    Tool("inspect_chemlight_emitter", "Read the hand mesh bounds and current ChemLight attachment point.",
         arguments(), inspect_chemlight_emitter),
    Tool("inspect_blueprint", "Read the event graph name and owned components on a Blueprint.",
         ASSET_SCHEMA, inspect_blueprint),
    Tool("graph_capabilities", "Check which Blueprint operations the live Zone Kit build exposes.",
         arguments(), graph_capabilities),
    Tool("create_blueprint", "Create a Blueprint in an editor-writable package.",
         arguments({"asset": string(PACKAGE), "parent_class": string(CLASS)},
                   required=("asset", "parent_class")), create_blueprint, read_only=False),
    Tool("add_blueprint_function", "Add a named function graph to a Blueprint.",
         arguments({**ASSET_ARGUMENT, "name": string(NAME)}, required=("asset", "name")),
         add_blueprint_function, read_only=False),
    Tool("add_blueprint_variable", "Add a typed member variable to a Blueprint.",
         arguments({**ASSET_ARGUMENT, "name": string(NAME),
                    "variable_type": {**string(NAME), "enum": list(VARIABLE_TYPES)}},
                   required=("asset", "name", "variable_type")), add_blueprint_variable, read_only=False),
    Tool("get_blueprint_default", "Read a scalar Blueprint class default.",
         arguments({**ASSET_ARGUMENT, "property_name": string(NAME)},
                   required=("asset", "property_name")), blueprint_default),
    Tool("set_blueprint_default", "Write a scalar class default on one Blueprint.",
         arguments({**ASSET_ARGUMENT, "property_name": string(NAME),
                    "value": {"type": ["boolean", "number", "string"]}},
                   required=("asset", "property_name", "value")), blueprint_default, read_only=False),
    Tool("inspect_graph", "List graph nodes and, when the native adapter is loaded, pins and links.",
         arguments(GRAPH_ARGUMENTS, required=("asset", "graph")),
         inspect_graph),
    Tool("export_blueprint_t3d", "Read a page of the editor's T3D export for one Blueprint.",
         arguments({**ASSET_ARGUMENT, "offset": {"type": "integer", "minimum": 0,
                    "maximum": 8 * 1024 * 1024, "default": 0}}, required=("asset",)),
         export_blueprint_t3d),
    Tool("add_function_call", "Add a call to a Blueprint-callable function through the native graph adapter.",
         arguments({**GRAPH_ARGUMENTS, "owner_class": string(CLASS), "function": string(NAME),
                    "x": GRAPH_COORDINATE, "y": GRAPH_COORDINATE},
                   required=("asset", "graph", "owner_class", "function", "x", "y")),
         add_function_call, read_only=False),
    Tool("ensure_event_override", "Find or add a parent-class event override in an event graph.",
         arguments({**GRAPH_ARGUMENTS, "event": string(NAME), "x": GRAPH_COORDINATE, "y": GRAPH_COORDINATE},
                   required=("asset", "graph", "event", "x", "y")),
         ensure_event_override, read_only=False),
    Tool("set_pin_default", "Set the validated literal default of an unconnected input pin.",
         arguments({**GRAPH_ARGUMENTS, "node": NODE_GUID, "pin": text(256),
                    "value": {"type": "string", "maxLength": 4096}},
                   required=("asset", "graph", "node", "pin", "value")),
         set_pin_default, read_only=False),
    Tool("import_graph_nodes", "Append Blueprint nodes from Unreal graph text using the optional native graph adapter.",
         arguments({**ASSET_ARGUMENT, "graph": string(NAME), "nodes_text": text(128 * 1024)},
                   required=("asset", "graph", "nodes_text")), import_graph_nodes, read_only=False),
    Tool("connect_graph_pins", "Connect existing Blueprint pins using the optional native graph adapter.",
         arguments({**ASSET_ARGUMENT, "graph": string(NAME),
                    "output_node": string("[A-Fa-f0-9]{32}"), "output_pin": text(256),
                    "input_node": string("[A-Fa-f0-9]{32}"), "input_pin": text(256)},
                   required=("asset", "graph", "output_node", "output_pin", "input_node", "input_pin")),
         connect_graph_pins, read_only=False),
    Tool("set_point_light", "Edit intensity, attenuation, source shape or shadows on a Blueprint Point Light. Leaves the asset unsaved.",
         arguments({**ASSET_ARGUMENT, "component": string(NAME),
                    **POINT_LIGHT_PARAMETERS},
                   required=("asset", "component"),
                   anyOf=[{"required": [name]} for name in POINT_LIGHT_PARAMETERS]),
         set_point_light, read_only=False),
    Tool("compile_blueprint", "Invoke Zone Kit's Blueprint compiler on one asset and report available status.",
         ASSET_SCHEMA, compile_blueprint, read_only=False),
    Tool("save_asset", "Save one asset, including any unsaved edits it already contains.",
         ASSET_SCHEMA, save_asset, read_only=False),
)}
