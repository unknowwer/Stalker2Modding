# Конфігурації GameData

Починай з `Stalker2/Content/GameLite/GameData` у встановленому SDK. Знайди конкретний SID і його найближчий робочий аналог, прочитай батьківські вузли та пов’язані таблиці. Для предметів простеж тип і слот, SID моделей, іконку й локалізацію, а за потреби також джерело видачі та поведінку при використанні. Зберігай кодування зразка, якщо він містить BOM або не-ASCII текст.

## Розміщення патчів

У таблиці `GameData` означає `Stalker2/Mods/<ModName>/Content/GameLite/GameData`. Для патчів зберігай відносну ієрархію цільового прототипу.

| Що змінюється | Файл у моді |
| --- | --- |
| Окремий звичайний конфіг, наприклад `CoreVariables.cfg` | `GameData/CoreVariables.cfg_patch_<ModName>` поруч із віртуальним шляхом оригіналу |
| Таблиця прототипів, наприклад `AnomalyPrototypes.cfg` | `GameData/AnomalyPrototypes/<UniqueName>.cfg` |
| Вкладена таблиця прототипів, наприклад `ItemPrototypes/DetectorPrototypes.cfg` | Перевір `GameData/ItemPrototypes/DetectorPrototypes/<UniqueName>.cfg`. Якщо потрібен шаблон зі штатного файла, вкажи його явним `refurl` і підтвердь завантаження в журналі |
| Новий прототип, яким керує окремий шлях Game Feature, наприклад новий World Map placeholder | Відповідний підкаталог `Content/GameLite/ModGameData` за схемою цієї системи й реєстрацією Game Feature. Звір фактичний шлях у своєму моді |

Сканер папки прототипу очікує звичайні файли з розширенням `.cfg`. Папка для патча може знадобитися навіть тоді, коли SDK містить лише однойменний кореневий файл. Для `MeshPrototypes.cfg` це означає перевірити `GameData/MeshPrototypes/<UniqueName>.cfg` як маршрут таблиці прототипів та підтвердити цей конкретний випадок у журналі. Для вкладених таблиць практичний приклад є в моді, який розміщує патч у `ItemPrototypes/AttachPrototypes/`. Перевіряй версію гри, бо PIE може читати вихідний CFG тоді, коли клієнт читає бінаризовану таблицю. [Застосування змін до CFG](https://cdn.stalker2.com/guides/How_to_apply_modifications_to_vanilla_.cfg_files.pdf) · [Бінаризовані таблиці](https://zonekit-support.stalker2.com/en-US/kb/article/145/config-patches) · [Mod Game Features](https://zonekit-support.stalker2.com/en-US/kb/article/162/mod-game-features) · [Вихідний код вкладеного прикладу](https://github.com/sdwvit/S2Mods/blob/master/Mods/X16Scopes/raw/Stalker2/Content/GameLite/GameData/ItemPrototypes/AttachPrototypes/AttachPrototypes_patch_X16Scopes.cfg)

## Гранулярність і посилання

- Для зміни окремого поля існуючого вузла використовуй `{bpatch}` на вузлі та на вкладених структурах, значення яких слід доповнити. Вузол із тим самим ключем без `{bpatch}` замінюється повністю. Застосовуй `removenode` під вузлом із `{bpatch}`, коли запит прямо потребує видалити поле або дочірній вузол. [Семантика патчів](https://zonekit-support.stalker2.com/en-US/kb/article/172/how-to-patch-contents-of-a-cfg-file)
- Для нового вузла вибери унікальний ключ і `SID` з префіксом мода. Перевір числовий `ID` там, де його використовує таблиця. Успадковуй потрібний штатний вузол через `refkey`. Для міжфайлового посилання в Phase 2 можна використати `refurl=@BaseGame/<відносний-шлях>;refkey=<ключ>`, якщо під час тесту активовано цей шлях конфігурації. Копіюй типізовані посилання на Unreal-асети з **Copy Reference**, перевіряючи різницю між шляхом асета і шляхом згенерованого Blueprint-класу. [Zone Kit Phase 2](https://www.stalker2.com/news/zone-kit-phase-2-new-features)
- Застосовуй унікальні назви файлів і мінімальні зміни ванільних вузлів. Якщо два моди змінюють одне поле або замінюють той самий вузол, перевір фактичний конфлікт та порядок застосування. [Діагностика конфліктів](https://zonekit-support.stalker2.com/en-US/kb/article/172/how-to-patch-contents-of-a-cfg-file)

Приклад зміни одного поля існуючого Echo для перевірки в `GameData/ItemPrototypes/DetectorPrototypes/<UniqueName>.cfg`.

```text
Echo : struct.begin {bpatch}
   Weight = 0.2
struct.end
```

## Перевірка завантаження

Вийди з PIE, підтвердь активний мод і скористайся **Reload Configs**, якщо команда доступна. За потреби повторно вибери мод або перезапусти редактор. Шукай у `LogConfigFileCache` виявлення файла, а в `LogParserNodePatching` його застосування і конфлікти. Якщо патч відсутній, спочатку звір тип таблиці, відносний шлях і розширення файла. Якщо файл виявлено, але SID не знайдено, перевір результат успадкування й посилання з інших прототипів. Для складного випадку ввімкни `-DumpConfigFileCache` або `-ProtoLoadingMode=2` і звір запис із потрібним файлом. [Аргументи запуску](https://zonekit-support.stalker2.com/en-US/kb/article/161/command-line-arguments-reference) · [Кеш конфігурацій](https://cdn.stalker2.com/guides/How_to_apply_modifications_to_vanilla_.cfg_files.pdf)

Для мода, який складається з конфігурацій, перевір синтаксис скриптів `CreatePlainMod.bat` та `PakPlainMod.bat` у корені конкретної інсталяції. У локальній збірці `2.1155` вони приймали назву мода першим аргументом. `PakPlainMod.bat` викликав `GSCCookModOverrideContent` із `-skipcook` і `-skipiostore`. Для нових `.uasset` використовуй повний процес приготування в редакторі. [Lesser Zone Kit](https://www.stalker2.com/news/zone-kit-phase-2-new-features)
