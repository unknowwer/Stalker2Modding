# Локальний міст Zone Kit

Користувач працює із Zone Kit через MCP. Використовуй сервер `flares-zonekit` для всіх дій у відкритому редакторі. Назва лишилася для сумісності з конфігурацією Codex. Міст v3 бачить гру, проєкт і змонтовані моди через реєстр UE.

## Перевірка сесії

1. Виклич `zonekit_status` і перевір назву проєкту, версію, стан реєстру та `writes_enabled`.
2. Виклич `zonekit_list_mounts`. Вибери каталог потрібної гри або мода, тоді звузь `zonekit_list_assets` до потрібної папки.
3. Для Blueprint виклич `zonekit_inspect_blueprint` та `zonekit_graph_capabilities`. Перевір сигнали живого редактора перед мутацією.
4. Після зміни повторно прочитай властивості, виклич `zonekit_compile_blueprint` і перевір відомий статус. Збережи лише потрібний асет через `zonekit_save_asset`. Якщо статус компіляції відсутній, відзнач, що підтверджено тільки виклик компілятора.

Якщо сесія неактивна, користувач запускає `zonekit_bridge.py` у Python-консолі Zone Kit. `Launch-ZoneKit.ps1` можна використати для наступного запуску редактора. MCP-конфіг має вказувати на сервер у тій самій папці, що й редакторний скрипт. [Запуск Python у Unreal Editor](https://dev.epicgames.com/documentation/en-us/unreal-engine/scripting-the-unreal-editor-using-python?application_version=5.5)

## Вибір інструмента

- `zonekit_get_asset` повертає клас і остаточний шлях. `zonekit_create_blueprint` створює асет із вказаним класом батька. `zonekit_add_blueprint_function` створює граф, а `zonekit_add_blueprint_variable` створює типізовану змінну.
- `zonekit_get_blueprint_default` і `zonekit_set_blueprint_default` працюють зі скалярними значеннями. `zonekit_set_point_light` редагує яскравість і радіус компонента, який належить самому Blueprint. Для потрібного штатного асета перевір маршрут Checkout. [Zone Kit Full Guide](https://zonekit-support.stalker2.com/en-US/kb/article/149/getting-started-with-zone-kit-or-zone-kit-full-guide)
- `zonekit_inspect_graph`, `zonekit_import_graph_nodes` і `zonekit_connect_graph_pins` потребують зібраного та завантаженого C++-адаптера. У штатній установленій збірці немає його необхідних заголовків. Якщо відповідна можливість повертає `false`, інспектуй інші доступні дані, підготуй T3D локально й повідом, що зміна вузлів чекає сумісної збірки адаптера. [UE 5.5 API імпорту вузлів](https://dev.epicgames.com/documentation/unreal-engine/API/Editor/UnrealEd/FEdGraphUtilities/ImportNodesFromText?application_version=5.5)

## Файли

- [Код моста й запуск](../scripts/zonekit-bridge/README.md) містить сервер stdio, скрипт редактора, реєстр інструментів, параметри та вихідний код адаптера.
- [Інструментарій Flares](../scripts/zonekit-bridge/Flares) містить перев’язування моделі ХІС до скелета Gilka, підготовку компонентів, генератор T3D і перевірку пакета. Готовий T3D є раннім прикладом життєвого циклу. Перед повторним імпортом звір його з поточними вимогами мода. Для ізольованого запуску інструментів скопіюй цю папку в робочу область.
